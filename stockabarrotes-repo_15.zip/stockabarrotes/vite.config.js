import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

export default defineConfig(({ mode }) => ({
  plugins: [react()],
  // En dev: base "/" para que Vite sirva los scripts correctamente.
  // En produccion: base "./" para que Electron los encuentre via file://
  base: mode === "production" ? "./" : "/",
  build: {
    outDir:              "dist",
    emptyOutDir:         true,
    sourcemap:           mode === "development",  // Solo en dev para debug
    chunkSizeWarningLimit: 600,                   // kB — suprimir advertencias normales
    rollupOptions: {
      output: {
        // Separar react del codigo de la app para caching eficiente
        manualChunks: {
          vendor: ["react", "react-dom"],
        },
      },
    },
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    port:       5173,
    strictPort: true,
    host:       "localhost",  // Solo localhost — no exponer en red local durante dev
  },
}));
