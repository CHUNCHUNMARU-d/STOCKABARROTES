const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("db", {
  app: {
    info:   ()       => ipcRenderer.invoke("app:info"),
  },
  backup: {
    crear:  ()       => ipcRenderer.invoke("backup:crear"),
  },
  productos: {
    listar:     ()       => ipcRenderer.invoke("productos:listar"),
    crear:      (data)   => ipcRenderer.invoke("productos:crear", data),
    actualizar: (data)   => ipcRenderer.invoke("productos:actualizar", data),
  },
  lotes: {
    listar:     (filtros) => ipcRenderer.invoke("lotes:listar", filtros),
    crear:      (data)    => ipcRenderer.invoke("lotes:crear", data),
    actualizar: (data)    => ipcRenderer.invoke("lotes:actualizar", data),
  },
  movimientos: {
    registrar:      (data)   => ipcRenderer.invoke("movimientos:registrar", data),
    registrarLote:  (items)  => ipcRenderer.invoke("movimientos:registrarLote", items),
    listar:         (filtros) => ipcRenderer.invoke("movimientos:listar", filtros),
  },
});
