const { app, BrowserWindow, ipcMain, dialog } = require("electron");
const path = require("path");
const fs   = require("fs");
const Database = require("better-sqlite3");

// isDev: true cuando se corre con `npm run dev`, false cuando es el instalador.
// app.isPackaged es poco fiable al correr con `electron .` desde la terminal.
const isDev = process.env.NODE_ENV === "development"
  || !app.isPackaged
  || process.argv.includes("--dev");

let db;
let mainWindow;

/* ─────────────────────────────────────────────────────────────────────────────
   BASE DE DATOS
───────────────────────────────────────────────────────────────────────────── */
function initDatabase() {
  const userDataPath = app.getPath("userData");
  const dbPath = path.join(userDataPath, "inventario.db");

  db = new Database(dbPath);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  // Sincronizacion normal — balance entre seguridad y velocidad
  db.pragma("synchronous = NORMAL");

  db.exec(`
    CREATE TABLE IF NOT EXISTS productos (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre        TEXT    NOT NULL,
      marca         TEXT    NOT NULL DEFAULT '',
      unidad        TEXT    NOT NULL DEFAULT 'Pieza',
      stock_minimo  INTEGER NOT NULL DEFAULT 5,
      precio        REAL    NOT NULL DEFAULT 0,
      codigo_barras TEXT    DEFAULT NULL,
      creado_en     TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
    );

    CREATE TABLE IF NOT EXISTS lotes (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      producto_id     INTEGER NOT NULL REFERENCES productos(id) ON DELETE CASCADE,
      cantidad        INTEGER NOT NULL DEFAULT 0,
      fecha_caducidad TEXT    NOT NULL,
      fecha_entrada   TEXT    NOT NULL DEFAULT (date('now','localtime'))
    );

    CREATE TABLE IF NOT EXISTS movimientos (
      id              INTEGER PRIMARY KEY AUTOINCREMENT,
      producto_id     INTEGER NOT NULL REFERENCES productos(id),
      lote_id         INTEGER REFERENCES lotes(id),
      tipo            TEXT    NOT NULL CHECK(tipo IN ('entrada','salida')),
      cantidad        INTEGER NOT NULL,
      motivo          TEXT    NOT NULL DEFAULT '',
      modo            TEXT    NOT NULL DEFAULT 'unidades',
      cajas           INTEGER DEFAULT NULL,
      unidades_caja   INTEGER DEFAULT NULL,
      fecha           TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
      usuario         TEXT    NOT NULL DEFAULT 'Admin'
    );

    CREATE INDEX IF NOT EXISTS idx_lotes_producto    ON lotes(producto_id);
    CREATE INDEX IF NOT EXISTS idx_lotes_caducidad   ON lotes(fecha_caducidad);
    CREATE INDEX IF NOT EXISTS idx_mov_producto      ON movimientos(producto_id);
    CREATE INDEX IF NOT EXISTS idx_mov_lote          ON movimientos(lote_id);
    CREATE INDEX IF NOT EXISTS idx_mov_fecha         ON movimientos(fecha);
  `);
}

function cerrarDatabase() {
  if (!db) return;
  try {
    // Fusionar el archivo WAL con la BD principal antes de cerrar.
    // Evita que el archivo .wal crezca indefinidamente con cortes de luz frecuentes.
    db.pragma("wal_checkpoint(TRUNCATE)");
    db.close();
    db = null;
  } catch (err) {
    console.error("Error al cerrar la base de datos:", err);
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
   VENTANA PRINCIPAL
───────────────────────────────────────────────────────────────────────────── */
function createWindow() {
  mainWindow = new BrowserWindow({
    width:     1200,
    height:    760,
    minWidth:  900,
    minHeight: 580,
    show:      false,
    title:     "StockAbarrotes",
    webPreferences: {
      preload:          path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration:  false,
    },
  });

  mainWindow.setMenuBarVisibility(false);

  // Mostrar la ventana cuando la pagina este lista
  mainWindow.webContents.on("did-finish-load", () => {
    mainWindow.maximize();
    mainWindow.show();
  });

  // Si la carga falla, mostrar igual para no dejar ventana invisible
  mainWindow.webContents.on("did-fail-load", (event, errorCode, errorDesc) => {
    console.error("Error al cargar la pagina:", errorCode, errorDesc);
    mainWindow.show();
  });

  if (isDev) {
    mainWindow.loadURL("http://localhost:5173");
  } else {
    mainWindow.loadFile(path.join(__dirname, "../dist/index.html"));
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
   CICLO DE VIDA DE LA APP
───────────────────────────────────────────────────────────────────────────── */
app.whenReady().then(() => {
  initDatabase();
  createWindow();
});

// Cierre limpio de la BD antes de que la app termine — incluye cortes de luz y
// cierres forzados desde el sistema operativo
app.on("will-quit", () => {
  cerrarDatabase();
});

// Fallback para el caso especifico de Windows (window-all-closed se dispara antes)
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    cerrarDatabase();
    app.quit();
  }
});

// Capturar errores no manejados para evitar que la app cierre sin guardar
process.on("uncaughtException", (err) => {
  console.error("Error no capturado:", err);
  cerrarDatabase();
});

process.on("unhandledRejection", (reason) => {
  console.error("Promesa rechazada sin manejar:", reason);
});

/* ─────────────────────────────────────────────────────────────────────────────
   INFO DE LA APP
───────────────────────────────────────────────────────────────────────────── */
ipcMain.handle("app:info", () => ({
  version:       app.getVersion(),
  nombre:        app.getName(),
  rutaDatos:     app.getPath("userData"),
  rutaBaseDatos: db ? path.join(app.getPath("userData"), "inventario.db") : null,
}));

/* ─────────────────────────────────────────────────────────────────────────────
   RESPALDO DE DATOS
───────────────────────────────────────────────────────────────────────────── */
ipcMain.handle("backup:crear", async () => {
  const hoy     = new Date();
  const fechaStr = hoy.toISOString().slice(0, 10).replace(/-/g, "");
  const horaStr  = hoy.toTimeString().slice(0, 5).replace(":", "");
  const nombreArchivo = `inventario_respaldo_${fechaStr}_${horaStr}.db`;

  const { filePath, canceled } = await dialog.showSaveDialog(mainWindow, {
    title:       "Guardar respaldo del inventario",
    defaultPath: nombreArchivo,
    filters:     [{ name: "Base de datos", extensions: ["db"] }],
  });

  if (canceled || !filePath) return { guardado: false };

  try {
    // Checkpoint antes de copiar para asegurar que el archivo .db este completo
    db.pragma("wal_checkpoint(FULL)");
    const origenDb = path.join(app.getPath("userData"), "inventario.db");
    fs.copyFileSync(origenDb, filePath);
    return { guardado: true, ruta: filePath };
  } catch (err) {
    return { guardado: false, error: err.message };
  }
});

/* ─────────────────────────────────────────────────────────────────────────────
   PRODUCTOS
───────────────────────────────────────────────────────────────────────────── */
ipcMain.handle("productos:listar", () =>
  db.prepare("SELECT * FROM productos ORDER BY nombre ASC").all()
);

ipcMain.handle("productos:crear", (_, data) => {
  const result = db.prepare(`
    INSERT INTO productos (nombre, marca, unidad, stock_minimo, precio, codigo_barras)
    VALUES (@nombre, @marca, @unidad, @stockMinimo, @precio, @codigoBarras)
  `).run(data);
  return db.prepare("SELECT * FROM productos WHERE id = ?").get(result.lastInsertRowid);
});

ipcMain.handle("productos:actualizar", (_, { id, ...data }) => {
  db.prepare(`
    UPDATE productos
    SET nombre=@nombre, marca=@marca, unidad=@unidad,
        stock_minimo=@stockMinimo, precio=@precio, codigo_barras=@codigoBarras
    WHERE id=@id
  `).run({ ...data, id });
  return db.prepare("SELECT * FROM productos WHERE id = ?").get(id);
});

/* ─────────────────────────────────────────────────────────────────────────────
   LOTES
───────────────────────────────────────────────────────────────────────────── */
ipcMain.handle("lotes:listar", (_, { productoId } = {}) => {
  if (productoId) {
    return db.prepare(
      "SELECT * FROM lotes WHERE producto_id = ? ORDER BY fecha_caducidad ASC"
    ).all(productoId);
  }
  return db.prepare("SELECT * FROM lotes ORDER BY fecha_caducidad ASC").all();
});

ipcMain.handle("lotes:crear", (_, data) => {
  const result = db.prepare(`
    INSERT INTO lotes (producto_id, cantidad, fecha_caducidad, fecha_entrada)
    VALUES (@productoId, @cantidad, @fechaCaducidad, @fechaEntrada)
  `).run(data);
  return db.prepare("SELECT * FROM lotes WHERE id = ?").get(result.lastInsertRowid);
});

ipcMain.handle("lotes:actualizar", (_, { id, cantidad }) => {
  db.prepare("UPDATE lotes SET cantidad = ? WHERE id = ?").run(cantidad, id);
  return db.prepare("SELECT * FROM lotes WHERE id = ?").get(id);
});

/* ─────────────────────────────────────────────────────────────────────────────
   MOVIMIENTOS
───────────────────────────────────────────────────────────────────────────── */
ipcMain.handle("movimientos:registrar", (_, data) => {
  const registrar = db.transaction((mov) => {
    const producto = db.prepare("SELECT id FROM productos WHERE id = ?").get(mov.productoId);
    if (!producto) throw new Error("Producto no encontrado");

    const lote = db.prepare("SELECT id, cantidad FROM lotes WHERE id = ?").get(mov.loteId);
    if (!lote) throw new Error("Lote no encontrado");

    if (mov.tipo === "salida") {
      if (lote.cantidad < mov.cantidad)
        throw new Error("Stock insuficiente en el lote. Disponible: " + lote.cantidad);
      db.prepare("UPDATE lotes SET cantidad = cantidad - ? WHERE id = ?")
        .run(mov.cantidad, mov.loteId);
    } else {
      db.prepare("UPDATE lotes SET cantidad = cantidad + ? WHERE id = ?")
        .run(mov.cantidad, mov.loteId);
    }

    const result = db.prepare(`
      INSERT INTO movimientos
        (producto_id, lote_id, tipo, cantidad, motivo, modo, cajas, unidades_caja, usuario)
      VALUES
        (@productoId, @loteId, @tipo, @cantidad, @motivo, @modo, @cajas, @unidadesCaja, @usuario)
    `).run({
      productoId:   mov.productoId,
      loteId:       mov.loteId,
      tipo:         mov.tipo,
      cantidad:     mov.cantidad,
      motivo:       mov.motivo        || "",
      modo:         mov.modo          || "unidades",
      cajas:        mov.cajas         || null,
      unidadesCaja: mov.unidadesCaja  || null,
      usuario:      mov.usuario       || "Admin",
    });

    return db.prepare("SELECT * FROM movimientos WHERE id = ?").get(result.lastInsertRowid);
  });

  return registrar(data);
});

ipcMain.handle("movimientos:listar", (_, { limite = 200, tipo = null, busqueda = null } = {}) => {
  let query = `
    SELECT m.*, p.nombre AS producto_nombre, p.marca AS producto_marca
    FROM movimientos m
    JOIN productos p ON m.producto_id = p.id
    WHERE 1=1
  `;
  const params = [];
  if (tipo)     { query += " AND m.tipo = ?";                             params.push(tipo); }
  if (busqueda) { query += " AND (p.nombre LIKE ? OR p.marca LIKE ?)";   params.push("%" + busqueda + "%", "%" + busqueda + "%"); }
  query += " ORDER BY m.fecha DESC LIMIT ?";
  params.push(limite);
  return db.prepare(query).all(...params);
});

/* ── Registrar multiples salidas en una sola transaccion atomica (carrito del escaner) */
ipcMain.handle("movimientos:registrarLote", (_, items) => {
  if (!Array.isArray(items) || items.length === 0)
    throw new Error("El lote de movimientos esta vacio");

  const registrarTodos = db.transaction((movs) => {
    const resultados = [];

    for (const mov of movs) {
      const producto = db.prepare("SELECT id FROM productos WHERE id = ?").get(mov.productoId);
      if (!producto) throw new Error("Producto " + mov.productoId + " no encontrado");

      const lote = db.prepare("SELECT id, cantidad FROM lotes WHERE id = ?").get(mov.loteId);
      if (!lote) throw new Error("Lote " + mov.loteId + " no encontrado");

      if (mov.tipo === "salida") {
        if (lote.cantidad < mov.cantidad)
          throw new Error("Stock insuficiente en lote " + mov.loteId + ". Disponible: " + lote.cantidad);
        db.prepare("UPDATE lotes SET cantidad = cantidad - ? WHERE id = ?")
          .run(mov.cantidad, mov.loteId);
      } else {
        db.prepare("UPDATE lotes SET cantidad = cantidad + ? WHERE id = ?")
          .run(mov.cantidad, mov.loteId);
      }

      const result = db.prepare(`
        INSERT INTO movimientos
          (producto_id, lote_id, tipo, cantidad, motivo, modo, cajas, unidades_caja, usuario)
        VALUES
          (@productoId, @loteId, @tipo, @cantidad, @motivo, @modo, @cajas, @unidadesCaja, @usuario)
      `).run({
        productoId:   mov.productoId,
        loteId:       mov.loteId,
        tipo:         mov.tipo,
        cantidad:     mov.cantidad,
        motivo:       mov.motivo        || "",
        modo:         mov.modo          || "unidades",
        cajas:        mov.cajas         || null,
        unidadesCaja: mov.unidadesCaja  || null,
        usuario:      mov.usuario       || "Admin",
      });

      resultados.push(db.prepare("SELECT * FROM movimientos WHERE id = ?").get(result.lastInsertRowid));
    }

    return resultados;
  });

  return registrarTodos(items);
});
