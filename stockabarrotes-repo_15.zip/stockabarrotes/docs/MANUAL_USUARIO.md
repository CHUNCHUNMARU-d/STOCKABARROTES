# Manual de usuario — StockAbarrotes

Versión 1.0 — Uso local sin internet

---

## Primeros pasos

Al abrir la aplicación verás el **Resumen general**. Desde el menú lateral izquierdo puedes acceder a todos los módulos del sistema.

---

## Módulo: Resumen general

Muestra un vistazo rápido del inventario:

- Cantidad total de productos registrados
- Productos que están completamente agotados
- Productos con stock por debajo del mínimo configurado
- Total de unidades que han entrado y salido

En la parte inferior aparece una tabla con los productos que necesitan atención inmediata.

---

## Módulo: Productos

Lista completa de todos los artículos registrados.

- Usa el campo de búsqueda para encontrar un producto por nombre o categoría
- Filtra por categoría usando el menú desplegable
- El color de fondo de cada fila cambia según el estado del stock:
  - Fondo rojizo: producto sin stock
  - Fondo amarillento: stock por debajo del mínimo
  - Sin color especial: stock normal

---

## Módulo: Agregar producto

Registra un producto nuevo en el sistema.

**Campos obligatorios:**
- **Nombre del producto** — escribe el nombre completo, por ejemplo "Azúcar blanca 1kg"
- **Precio unitario** — el precio al que vendes el producto

**Campos opcionales:**
- **Categoría** — selecciona la categoría que corresponda
- **Unidad de medida** — pieza, caja, botella, etc.
- **Stock mínimo de alerta** — cantidad a partir de la cual el sistema te avisará que el producto está bajo. Por ejemplo, si pones 10, el sistema te alertará cuando queden menos de 10 unidades

El stock inicial siempre empieza en cero. Para agregar existencias usa el módulo de **Registrar entrada**.

---

## Módulo: Registrar entrada

Usa este módulo cuando llegue mercancía a la tienda.

1. Selecciona el producto de la lista desplegable
2. Escribe la cantidad de unidades que llegaron
3. Selecciona el motivo (compra a proveedor, devolución, etc.)
4. Antes de confirmar verás un resumen que muestra el stock actual y el stock nuevo

El sistema actualiza el inventario y guarda el movimiento en el historial automáticamente.

---

## Módulo: Registrar salida

Usa este módulo para descontar productos del inventario.

1. Selecciona el producto de la lista
2. Escribe la cantidad que sale
3. Selecciona el motivo (venta, merma, daño, etc.)

**Nota:** Si intentas registrar una salida mayor al stock disponible, el sistema te lo avisará y no dejará completar el registro.

---

## Módulo: Historial de movimientos

Muestra todos los movimientos registrados, del más reciente al más antiguo.

- **Buscar** — filtra por nombre de producto
- **Tipo** — muestra solo entradas, solo salidas, o todos
- Cada movimiento muestra la fecha, el producto, si fue entrada o salida, la cantidad y el motivo

---

## Respaldo de datos

Para hacer una copia de seguridad de todo el inventario:

1. Cierra la aplicación
2. Abre el Explorador de archivos de Windows
3. Escribe esta ruta en la barra de direcciones:

   ```
   %APPDATA%\StockAbarrotes
   ```

4. Copia el archivo `inventario.db` a una USB o carpeta de respaldo

Para restaurar una copia de seguridad, simplemente pega el archivo `inventario.db` de regreso en esa carpeta.

---

## Solución de problemas comunes

**La aplicación no abre**
Verifica que el instalador se haya completado correctamente. Intenta desinstalar y volver a instalar.

**Aparece el mensaje "Stock insuficiente"**
El producto seleccionado no tiene suficientes unidades para registrar la salida. Verifica la cantidad disponible en el módulo de Productos.

**No encuentro un producto en la lista**
Puede que tenga un nombre diferente al que buscas. Prueba buscando solo una parte del nombre, por ejemplo "arroz" en lugar de "Arroz blanco 1kg".

**Los datos desaparecieron**
Verifica que el archivo `inventario.db` sigue en la carpeta `%APPDATA%\StockAbarrotes`. Si tienes un respaldo, cópialo de regreso a esa carpeta.
