// StockAbarrotes v2 — Componente principal React
// Version de produccion — sin datos de prueba

import React, { useState, useEffect, useCallback, useRef, useMemo } from "react";

/* ─────────────────────────────────────────────────────────────────────────────
   CONSTANTES GLOBALES
───────────────────────────────────────────────────────────────────────────── */

const MS_POR_DIA = 86400000;


/** Valor inicial de unidades — el usuario puede modificar esta lista desde la app */
const UNIDADES_MEDIDA_INICIALES = ["Pieza","Caja","Botella","Bolsa","Lata","Paquete","Litro","Kilogramo","Gramo","Manojo"];
const MOTIVOS_ENTRADA = ["Compra proveedor","Devolucion de cliente","Ajuste de inventario","Donacion"];
const MOTIVOS_SALIDA  = ["Venta","Merma / vencido","Dano en almacen","Ajuste","Uso interno","Consumo propio"];

/** Divisas disponibles para mostrar en la app */
const DIVISAS_DISPONIBLES = [
  { codigo: "MXN", simbolo: "$",  nombre: "Peso mexicano",      ejemplo: "$ 22.50" },
  { codigo: "USD", simbolo: "US$", nombre: "Dólar americano",    ejemplo: "US$ 1.30" },
  { codigo: "EUR", simbolo: "€",  nombre: "Euro",                ejemplo: "€ 1.20" },
  { codigo: "GTQ", simbolo: "Q",  nombre: "Quetzal guatemalteco",ejemplo: "Q 10.00" },
  { codigo: "HNL", simbolo: "L",  nombre: "Lempira hondureño",  ejemplo: "L 32.00" },
];

const SECCIONES_NAVEGACION = [
  {
    titulo: null,
    vistas: [{ key: "dashboard", label: "Resumen inteligente" }],
  },
  {
    titulo: "Inventario",
    vistas: [
      { key: "productos", label: "Productos" },
      { key: "lotes",     label: "Lotes y caducidades" },
    ],
  },
  {
    titulo: "Movimientos",
    vistas: [
      { key: "entrada", label: "Registrar entrada" },
      { key: "salida",  label: "Registrar salida"  },
      { key: "escaner", label: "Escaner" },
    ],
  },
  {
    titulo: "Consulta",
    vistas: [{ key: "historial", label: "Historial" }],
  },
  {
    titulo: "Configuracion",
    vistas: [
      { key: "nuevo",    label: "Agregar producto"   },
      { key: "unidades", label: "Unidades de medida" },
      { key: "divisa",   label: "Divisa / Moneda"    },
    ],
  },
];


/* ─────────────────────────────────────────────────────────────────────────────
   UTILIDADES PURAS
───────────────────────────────────────────────────────────────────────────── */
const calcularDiasRestantes = (fechaIso) => {
  const hoy      = new Date(); hoy.setHours(0,0,0,0);
  const fechaObj = new Date(fechaIso); fechaObj.setHours(0,0,0,0);
  return Math.round((fechaObj - hoy) / MS_POR_DIA);
};

const formatearFecha = (fechaIso) => {
  if (!fechaIso) return "—";
  const anio = fechaIso.slice(0,4);
  const [, mes, dia] = fechaIso.split("-");
  return `${dia}/${mes}/${anio}`;
};

const obtenerFechaHoraActual = () => {
  const fechaActual = new Date();
  return fechaActual.toISOString().slice(0,10) + " " + fechaActual.toTimeString().slice(0,5);
};

const siguienteId = (arreglo) => Math.max(0, ...arreglo.map((item) => item.id)) + 1;

/** Contador incremental para IDs de items del carrito — evita colisiones de Date.now() */
let _contadorIdCarrito = 1;
const generarIdCarrito = () => _contadorIdCarrito++;

/* ─────────────────────────────────────────────────────────────────────────────
   ESTILOS COMPARTIDOS
───────────────────────────────────────────────────────────────────────────── */
const ESTILOS = {
  encabezadoTabla: { padding:"9px 11px", fontSize:12, fontWeight:500, color:"#5f5e5a", borderBottom:"0.5px solid #e5e4dc", textAlign:"left", whiteSpace:"nowrap" },
  celdaTabla:      { padding:"10px 11px", fontSize:13, borderBottom:"0.5px solid #e5e4dc" },
  tarjeta:         { background:"#fff", border:"0.5px solid #e5e4dc", borderRadius:12, overflow:"hidden" },
  formulario:      { background:"#fff", border:"0.5px solid #e5e4dc", borderRadius:12, padding:"1.25rem" },
  inputBase:       { width:"100%", padding:"8px 10px", border:"0.5px solid #d1d0c8", borderRadius:8, fontSize:13 },
};

/* ─────────────────────────────────────────────────────────────────────────────
   VALORES INICIALES DE FORMULARIOS
───────────────────────────────────────────────────────────────────────────── */
const FORM_PRODUCTO_VACIO = {
  nombre:"", marca:"", unidad:"Pieza", stockMinimo:5,
  precio:"", codigoBarras:"",
  // Precio por cajas: si modoPrecio="caja", precio = precioPorCaja / unidadesPorCajaPrecio
  modoPrecio:          "unidad",  // "unidad" | "caja"
  precioPorCaja:       "",
  unidadesPorCajaPrecio: "",
};

/** Estructura del formulario de edición de un movimiento existente */
const FORM_EDICION_MOVIMIENTO_VACIO = {
  id:          null,
  cantidad:    "",
  motivo:      "",
  tipo:        "",   // "entrada" | "salida" — solo lectura, no se puede cambiar el tipo
  cantidadOriginal: 0,
  loteId:      null,
};
const FORM_ENTRADA_VACIO  = { productoId:"", loteId:"nueva", caducidad:"", modo:"unidades", cajas:"", unidadesCaja:"", cantidad:"", motivo:MOTIVOS_ENTRADA[0] };
const FORM_SALIDA_VACIO   = { productoId:"", loteId:"", cantidad:"", motivo:MOTIVOS_SALIDA[0] };

/* ─────────────────────────────────────────────────────────────────────────────
   COMPONENTES AUXILIARES
───────────────────────────────────────────────────────────────────────────── */
function MensajeAlerta({ mensaje, tipo }) {
  if (!mensaje) return null;
  const esExito = tipo === "ok";
  return (
    <div style={{ background:esExito?"#EAF3DE":"#FCEBEB", color:esExito?"#27500A":"#791F1F",
      border:`0.5px solid ${esExito?"#97C459":"#F09595"}`, borderRadius:8, padding:"10px 14px", fontSize:13, marginBottom:14 }}>
      {mensaje}
    </div>
  );
}

function EstadoLoteBadge({ diasRestantesLote }) {
  const base = { fontSize:11, padding:"2px 9px", borderRadius:20, fontWeight:500, whiteSpace:"nowrap" };
  if (diasRestantesLote < 0)   return <span style={{ ...base, background:"#FCEBEB", color:"#791F1F", border:"0.5px solid #F09595" }}>Caducado</span>;
  if (diasRestantesLote <= 7)  return <span style={{ ...base, background:"#FCEBEB", color:"#791F1F", border:"0.5px solid #F09595" }}>Vence en {diasRestantesLote}d</span>;
  if (diasRestantesLote <= 15) return <span style={{ ...base, background:"#FAEEDA", color:"#633806", border:"0.5px solid #EF9F27" }}>Vence en {diasRestantesLote}d</span>;
  return <span style={{ ...base, background:"#EAF3DE", color:"#27500A", border:"0.5px solid #97C459" }}>OK</span>;
}

function CampoFormulario({ etiqueta, obligatorio, children }) {
  return (
    <div style={{ marginBottom:13 }}>
      <label style={{ display:"block", fontSize:12, color:"#5f5e5a", marginBottom:5 }}>
        {etiqueta}{obligatorio && <span style={{ color:"#a32d2d", marginLeft:3 }}>*</span>}
      </label>
      {children}
    </div>
  );
}


/* ─────────────────────────────────────────────────────────────────────────────
   SELECTOR DE PRODUCTO CON BUSQUEDA
   Reemplaza el <select> estandar con un campo buscable por nombre y marca
───────────────────────────────────────────────────────────────────────────── */
function SelectorProductoBuscable({ productos, stockPorProductoId, productoIdSeleccionado, alCambiar, placeholder }) {
  const [textoBusqueda, setTextoBusqueda]   = useState("");
  const [estaAbierto,   setEstaAbierto]     = useState(false);
  const refContenedor                       = useRef(null);
  const refInputBusqueda                    = useRef(null);

  const productoSeleccionado = productoIdSeleccionado
    ? productos.find((p) => p.id === parseInt(productoIdSeleccionado))
    : null;

  // Cerrar al hacer clic fuera del componente
  useEffect(() => {
    const manejarClicExterno = (e) => {
      if (refContenedor.current && !refContenedor.current.contains(e.target))
        setEstaAbierto(false);
    };
    document.addEventListener("mousedown", manejarClicExterno);
    return () => document.removeEventListener("mousedown", manejarClicExterno);
  }, []);

  // Enfocar el input al abrir el selector (autoFocus no funciona en actualizaciones, solo en mount)
  useEffect(() => {
    if (estaAbierto && refInputBusqueda.current) refInputBusqueda.current.focus();
  }, [estaAbierto]);

  const productosFiltrados = useMemo(() => {
    const termino = textoBusqueda.toLowerCase();
    if (!termino) return productos;
    return productos.filter((p) =>
      p.nombre.toLowerCase().includes(termino) || p.marca.toLowerCase().includes(termino)
    );
  }, [productos, textoBusqueda]);

  const seleccionarProducto = (producto) => {
    alCambiar(producto.id.toString());
    setTextoBusqueda("");
    setEstaAbierto(false);
  };

  const limpiarSeleccion = () => { alCambiar(""); setTextoBusqueda(""); setEstaAbierto(true); };

  return (
    <div ref={refContenedor} style={{ position: "relative" }}>
      {productoSeleccionado && !estaAbierto ? (
        <div
          onClick={() => setEstaAbierto(true)}
          style={{ display:"flex", alignItems:"center", gap:8, padding:"8px 10px", border:"0.5px solid #97C459", borderRadius:8, background:"#EAF3DE", cursor:"pointer" }}>
          <div style={{ flex:1 }}>
            <span style={{ fontSize:13, fontWeight:500, color:"#27500A" }}>{productoSeleccionado.nombre}</span>
            <span style={{ fontSize:12, color:"#3B6D11", marginLeft:6 }}>{productoSeleccionado.marca}</span>
            <span style={{ fontSize:12, color:"#5f5e5a", marginLeft:8 }}>
              stock: {stockPorProductoId[productoSeleccionado.id] || 0}
            </span>
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); limpiarSeleccion(); }}
            style={{ border:"none", background:"transparent", cursor:"pointer", fontSize:18, color:"#888780", lineHeight:1, padding:"0 2px" }}>
            ×
          </button>
        </div>
      ) : (
        <input
          ref={refInputBusqueda}
          value={textoBusqueda}
          onChange={(e) => { setTextoBusqueda(e.target.value); setEstaAbierto(true); }}
          onFocus={() => setEstaAbierto(true)}
          placeholder={placeholder || "Buscar por nombre o marca..."}
          style={ESTILOS.inputBase}
        />
      )}
      {estaAbierto && (
        <div style={{ position:"absolute", top:"calc(100% + 2px)", left:0, right:0, background:"#fff", border:"0.5px solid #d1d0c8", borderRadius:8, zIndex:200, maxHeight:230, overflowY:"auto", boxShadow:"0 4px 16px rgba(0,0,0,.1)" }}>
          {productosFiltrados.length === 0 ? (
            <div style={{ padding:"12px 14px", fontSize:13, color:"#888780" }}>Sin resultados para "{textoBusqueda}"</div>
          ) : productosFiltrados.map((producto) => {
            const stockActual = stockPorProductoId[producto.id] || 0;
            const colorStock  = stockActual === 0 ? "#791F1F" : stockActual < producto.stockMinimo ? "#633806" : "#27500A";
            return (
              <div key={producto.id}
                onClick={() => seleccionarProducto(producto)}
                onMouseEnter={(e) => e.currentTarget.style.background = "#f5f4f0"}
                onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
                style={{ padding:"10px 14px", cursor:"pointer", borderBottom:"0.5px solid #f1efe8", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <div>
                  <div style={{ fontSize:13, fontWeight:500 }}>{producto.nombre}</div>
                  <div style={{ fontSize:11, color:"#888780" }}>{producto.marca} · {producto.unidad}</div>
                </div>
                <div style={{ fontSize:12, fontWeight:500, color:colorStock }}>{stockActual} uds</div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ═════════════════════════════════════════════════════════════════════════════
   COMPONENTE PRINCIPAL
═════════════════════════════════════════════════════════════════════════════ */
export default function App() {

  const [vistaActiva, setVistaActiva]   = useState("dashboard");
  const [productos, setProductos]       = useState([]);
  const [lotes, setLotes]               = useState([]);
  const [movimientos, setMovimientos]   = useState([]);
  const [alertaActual, setAlertaActual] = useState(null);
  const timerAlerta                     = useRef(null);

  const [textoBusquedaProductos, setTextoBusquedaProductos] = useState("");
  const [textoBusquedaHistorial, setTextoBusquedaHistorial] = useState("");
  const [filtroTipoMovimiento,   setFiltroTipoMovimiento]   = useState("");

  const [formProducto, setFormProducto] = useState(FORM_PRODUCTO_VACIO);
  const [formEntrada,  setFormEntrada]  = useState(FORM_ENTRADA_VACIO);
  const [formSalida,   setFormSalida]   = useState(FORM_SALIDA_VACIO);

  const [codigoEscaneado,       setCodigoEscaneado]       = useState("");
  const [resultadoEscaneo,      setResultadoEscaneo]      = useState(null);
  const [cantidadScanSalida,    setCantidadScanSalida]    = useState(1);
  const [motivoScanSalida,      setMotivoScanSalida]      = useState(MOTIVOS_SALIDA[0]);
  const [carritoEscaneo,        setCarritoEscaneo]        = useState([]);
  const inputScannerRef = useRef(null);

  /** Divisa activa — afecta el símbolo visible en todas las tablas y formularios */
  const [divisaActual, setDivisaActual] = useState(DIVISAS_DISPONIBLES[0]);

  /** Lista editable de unidades de medida — el usuario puede agregar/editar/eliminar */
  const [unidadesMedida, setUnidadesMedida] = useState(UNIDADES_MEDIDA_INICIALES);
  /** ID del producto que se está editando. null = modo creación */
  const [idProductoEditando, setIdProductoEditando] = useState(null);
  /** Estado del formulario para gestionar unidades de medida */
  const [nuevaUnidad, setNuevaUnidad] = useState("");
  /** ID de la unidad siendo editada inline */
  const [idUnidadEditando, setIdUnidadEditando] = useState(null);
  /** Texto en edición de una unidad */
  const [textoUnidadEditando, setTextoUnidadEditando] = useState("");
  /** Confirmación de eliminación de producto — guarda el id del producto a eliminar */
  const [idProductoAEliminar, setIdProductoAEliminar] = useState(null);

  /** ID del movimiento que está siendo editado. null = ninguno abierto */
  const [idMovimientoEditando, setIdMovimientoEditando] = useState(null);
  /** Datos del formulario de edición del movimiento activo */
  const [formEdicionMovimiento, setFormEdicionMovimiento] = useState(FORM_EDICION_MOVIMIENTO_VACIO);

  /* ── Alertas UI ─────────────────────────────────────────────────────── */
  const mostrarAlerta = useCallback((mensaje, tipo = "ok") => {
    setAlertaActual({ mensaje, tipo });
    if (timerAlerta.current) clearTimeout(timerAlerta.current);
    timerAlerta.current = setTimeout(() => setAlertaActual(null), 4000);
  }, []);

  /** Formatea un número como precio con el símbolo de la divisa activa */
  const fmtPrecio = (monto) => `${divisaActual.simbolo} ${Number(monto).toFixed(2)}`;

  /* ── Valores derivados ──────────────────────────────────────────────── */
  const stockTotalPorProductoId = useMemo(() =>
    productos.reduce((acumulador, producto) => {
      acumulador[producto.id] = lotes
        .filter((lote) => lote.productoId === producto.id)
        .reduce((suma, lote) => suma + lote.cantidad, 0);
      return acumulador;
    }, {}),
  [productos, lotes]);

  const lotesEnriquecidos = useMemo(() =>
    lotes.map((lote) => ({
      ...lote,
      diasRestantes: calcularDiasRestantes(lote.fechaCaducidad),
      producto:      productos.find((p) => p.id === lote.productoId),
    })),
  [lotes, productos]);

  const lotesCaducados     = useMemo(() => lotesEnriquecidos.filter((l) => l.diasRestantes < 0  && l.cantidad > 0), [lotesEnriquecidos]);
  const lotesPorVencer7d   = useMemo(() => lotesEnriquecidos.filter((l) => l.diasRestantes >= 0 && l.diasRestantes <= 7  && l.cantidad > 0), [lotesEnriquecidos]);
  const lotesPorVencer15d  = useMemo(() => lotesEnriquecidos.filter((l) => l.diasRestantes > 7  && l.diasRestantes <= 15 && l.cantidad > 0), [lotesEnriquecidos]);
  const productosStockBajo = useMemo(() => productos.filter((p) => (stockTotalPorProductoId[p.id] || 0) < p.stockMinimo), [productos, stockTotalPorProductoId]);

  /* ── Exportar resumen a PDF ─────────────────────────────────────────── */
  const exportarResumenPDF = useCallback(() => {
    const fechaFormateada = new Date().toLocaleDateString("es-MX", { day:"2-digit", month:"long",   year:"numeric" });
    const horaFormateada  = new Date().toLocaleTimeString("es-MX", { hour:"2-digit", minute:"2-digit" });

    const filaLotePDF = (lote, colorFondo) => `
      <tr style="background:${colorFondo}">
        <td>${lote.producto?.nombre || ""}</td>
        <td>${lote.producto?.marca  || ""}</td>
        <td style="text-align:center">${lote.cantidad}</td>
        <td style="text-align:center">${formatearFecha(lote.fechaCaducidad)}</td>
        <td style="text-align:center">${lote.diasRestantes < 0 ? "Caducado" : `Vence en ${lote.diasRestantes}d`}</td>
      </tr>`;

    const seccionLotesPDF = (titulo, colorTitulo, lotesSeccion, colorFondoFilas) =>
      lotesSeccion.length === 0 ? "" : `
        <h3 style="color:${colorTitulo};margin:18px 0 6px">${titulo}</h3>
        <table>
          <thead><tr><th>Producto</th><th>Marca</th><th>Cant.</th><th>Caducidad</th><th>Estado</th></tr></thead>
          <tbody>${lotesSeccion.map((l) => filaLotePDF(l, colorFondoFilas)).join("")}</tbody>
        </table>`;

    const seccionStockBajoPDF = productosStockBajo.length === 0 ? "" : `
      <h3 style="margin:18px 0 6px">Productos con stock bajo</h3>
      <table>
        <thead><tr><th>Producto</th><th>Marca</th><th>Stock actual</th><th>Stock minimo</th></tr></thead>
        <tbody>${productosStockBajo.map((p) => `
          <tr>
            <td>${p.nombre}</td>
            <td>${p.marca}</td>
            <td style="text-align:center;color:${(stockTotalPorProductoId[p.id]||0)===0?"#791F1F":"#633806"};font-weight:600">${stockTotalPorProductoId[p.id]||0}</td>
            <td style="text-align:center">${p.stockMinimo}</td>
          </tr>`).join("")}
        </tbody>
      </table>`;

    const hayAlertas = lotesCaducados.length > 0 || lotesPorVencer7d.length > 0 ||
                       lotesPorVencer15d.length > 0 || productosStockBajo.length > 0;

    const htmlReporte = `<!DOCTYPE html><html lang="es"><head>
      <meta charset="UTF-8">
      <title>Resumen inteligente — StockAbarrotes</title>
      <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Segoe UI',system-ui,sans-serif;font-size:11px;color:#1a1a1a;padding:28px 32px}
        .encabezado{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:1.5px solid #1a1a1a;padding-bottom:10px;margin-bottom:16px}
        .encabezado h1{font-size:20px;font-weight:600}
        .encabezado .subtitulo{font-size:10px;color:#5f5e5a;margin-top:3px}
        .encabezado .timestamp{font-size:10px;color:#5f5e5a;text-align:right}
        .metricas{display:flex;gap:10px;margin-bottom:18px}
        .metrica{flex:1;background:#f1efe8;border-radius:6px;padding:10px 12px}
        .metrica .valor{font-size:20px;font-weight:700;line-height:1.1}
        .metrica .etiqueta{font-size:9px;color:#5f5e5a;margin-top:2px}
        table{width:100%;border-collapse:collapse;margin-bottom:6px;font-size:10.5px}
        th{background:#e8e7e0;padding:6px 8px;text-align:left;font-weight:600;border-bottom:1px solid #d1d0c8}
        td{padding:6px 8px;border-bottom:0.5px solid #e5e4dc}
        h3{font-size:12px}
        .caja-ok{background:#EAF3DE;border:1px solid #97C459;border-radius:8px;padding:16px;text-align:center;color:#27500A;margin-top:12px}
        .caja-ok .titulo-ok{font-size:18px;font-weight:700;margin-bottom:4px}
        .pie-pagina{margin-top:24px;border-top:0.5px solid #e5e4dc;padding-top:8px;font-size:9px;color:#888780;display:flex;justify-content:space-between}
        @media print{body{padding:16px 20px}@page{margin:12mm}}
      </style>
    </head><body>
      <div class="encabezado">
        <div><h1>Resumen inteligente</h1><div class="subtitulo">StockAbarrotes — Reporte de inventario</div></div>
        <div class="timestamp">Generado el ${fechaFormateada} a las ${horaFormateada}</div>
      </div>
      <div class="metricas">
        <div class="metrica"><div class="valor">${productos.length}</div><div class="etiqueta">Productos registrados</div></div>
        <div class="metrica"><div class="valor" style="color:${lotesCaducados.length>0?"#791F1F":"inherit"}">${lotesCaducados.length}</div><div class="etiqueta">Lotes caducados</div></div>
        <div class="metrica"><div class="valor" style="color:${lotesPorVencer7d.length>0?"#854F0B":"inherit"}">${lotesPorVencer7d.length}</div><div class="etiqueta">Vencen en 7 dias</div></div>
        <div class="metrica"><div class="valor" style="color:${lotesPorVencer15d.length>0?"#854F0B":"inherit"}">${lotesPorVencer15d.length}</div><div class="etiqueta">Vencen en 15 dias</div></div>
        <div class="metrica"><div class="valor" style="color:${productosStockBajo.length>0?"#854F0B":"inherit"}">${productosStockBajo.length}</div><div class="etiqueta">Stock bajo</div></div>
      </div>
      ${seccionLotesPDF("Lotes caducados — accion inmediata",      "#791F1F", lotesCaducados,   "#fff5f5")}
      ${seccionLotesPDF("Proximos a caducar — dentro de 7 dias",  "#854F0B", lotesPorVencer7d, "#fffbf0")}
      ${seccionLotesPDF("Proximos a caducar — dentro de 15 dias", "#5f5e5a", lotesPorVencer15d,"#fafaf8")}
      ${seccionStockBajoPDF}
      ${!hayAlertas ? `<div class="caja-ok"><div class="titulo-ok">Todo en orden</div><div>Sin alertas activas al momento de generar este reporte.</div></div>` : ""}
      <div class="pie-pagina">
        <span>StockAbarrotes v2 — Sistema de inventario local</span>
        <span>Reporte generado automaticamente</span>
      </div>
    </body></html>`;

    const ventanaReporte = window.open("", "_blank", "width=850,height=700");
    if (!ventanaReporte) { mostrarAlerta("El navegador bloqueo la ventana emergente. Permite ventanas emergentes e intenta de nuevo.", "err"); return; }
    ventanaReporte.document.write(htmlReporte);
    ventanaReporte.document.close();
    ventanaReporte.focus();
    setTimeout(() => ventanaReporte.print(), 400);
  }, [productos, lotesCaducados, lotesPorVencer7d, lotesPorVencer15d, productosStockBajo, stockTotalPorProductoId, mostrarAlerta]);

  /* ── Respaldo de la base de datos ───────────────────────────────────── */
  const hacerRespaldo = useCallback(async () => {
    // En el prototipo (sin Electron) simula el mensaje
    if (!window.db?.backup?.crear) {
      mostrarAlerta("Funcion disponible en la aplicacion instalada.", "err");
      return;
    }
    mostrarAlerta("Abriendo dialogo para guardar respaldo...");
    const resultado = await window.db.backup.crear();
    if (resultado.guardado) {
      mostrarAlerta("Respaldo guardado correctamente.");
    } else if (resultado.error) {
      mostrarAlerta("Error al guardar el respaldo: " + resultado.error, "err");
    }
    // Si resultado.guardado === false sin error, el usuario cancelo el dialogo
  }, [mostrarAlerta]);

  /* ── Valores derivados para vistas especificas ──────────────────────── */
  const lotesDisponiblesParaSalida = useMemo(() => {
    if (!formSalida.productoId) return [];
    return lotes
      .filter((l) => l.productoId === parseInt(formSalida.productoId) && l.cantidad > 0)
      .map((l) => ({ ...l, diasRestantes: calcularDiasRestantes(l.fechaCaducidad) }))
      .sort((a, b) => a.diasRestantes - b.diasRestantes);
  }, [formSalida.productoId, lotes]);

  const lotesExistentesProductoEntrada = useMemo(() => {
    if (!formEntrada.productoId) return [];
    return lotes.filter((l) => l.productoId === parseInt(formEntrada.productoId));
  }, [formEntrada.productoId, lotes]);

  const movimientosFiltrados = useMemo(() =>
    movimientos.filter((movimiento) => {
      const terminoBusqueda = textoBusquedaHistorial.toLowerCase();
      const producto = productos.find((p) => p.id === movimiento.productoId);
      const coincideTexto = !terminoBusqueda ||
        producto?.nombre.toLowerCase().includes(terminoBusqueda) ||
        producto?.marca.toLowerCase().includes(terminoBusqueda);
      const coincideTipo = !filtroTipoMovimiento || movimiento.tipo === filtroTipoMovimiento;
      return coincideTexto && coincideTipo;
    }),
  [movimientos, textoBusquedaHistorial, filtroTipoMovimiento, productos]);

  const productosFiltrados = useMemo(() =>
    productos.filter((producto) => {
      const terminoBusqueda = textoBusquedaProductos.toLowerCase();
      return !terminoBusqueda ||
        producto.nombre.toLowerCase().includes(terminoBusqueda) ||
        producto.marca.toLowerCase().includes(terminoBusqueda);
    }),
  [productos, textoBusquedaProductos]);

  /* ── Handlers ───────────────────────────────────────────────────────── */
  const guardarProducto = () => {
    if (!formProducto.nombre.trim()) return mostrarAlerta("Ingresa el nombre del producto.", "err");
    if (!formProducto.marca.trim())  return mostrarAlerta("Ingresa la marca del producto.", "err");

    // Calcular precio unitario según el modo seleccionado
    let precioUnitario;
    if (formProducto.modoPrecio === "caja") {
      const precioCaja    = parseFloat(formProducto.precioPorCaja);
      const udsXCaja      = parseInt(formProducto.unidadesPorCajaPrecio);
      if (!precioCaja || isNaN(precioCaja) || precioCaja <= 0)
        return mostrarAlerta("Ingresa el precio por caja.", "err");
      if (!udsXCaja || udsXCaja <= 0)
        return mostrarAlerta("Ingresa cuantas unidades trae la caja.", "err");
      precioUnitario = precioCaja / udsXCaja;
    } else {
      if (!formProducto.precio || isNaN(formProducto.precio))
        return mostrarAlerta("Ingresa un precio unitario valido.", "err");
      precioUnitario = parseFloat(formProducto.precio);
    }

    const datosProducto = {
      nombre:       formProducto.nombre.trim(),
      marca:        formProducto.marca.trim(),
      unidad:       formProducto.unidad,
      stockMinimo:  parseInt(formProducto.stockMinimo) || 5,
      precio:       precioUnitario,
      codigoBarras: formProducto.codigoBarras?.trim() || null,
    };

    // Verificar que el código de barras no esté duplicado
    const codigoBarrasNuevo = formProducto.codigoBarras?.trim() || null;
    if (codigoBarrasNuevo) {
      const productoConMismoCodigo = productos.find(
        (p) => p.codigoBarras === codigoBarrasNuevo && p.id !== idProductoEditando
      );
      if (productoConMismoCodigo) {
        return mostrarAlerta(
          `El código de barras ya pertenece a "${productoConMismoCodigo.nombre} — ${productoConMismoCodigo.marca}". Cada producto debe tener un código único.`,
          "err"
        );
      }
    }

    const nombreProducto = formProducto.nombre;

    if (idProductoEditando) {
      // Modo edición — actualizar producto existente
      setProductos((productosActuales) =>
        productosActuales.map((p) =>
          p.id === idProductoEditando ? { ...p, ...datosProducto } : p
        )
      );
      mostrarAlerta(`Producto "${nombreProducto}" actualizado.`);
      setIdProductoEditando(null);
    } else {
      // Modo creación — agregar nuevo producto
      const nuevoProducto = { id: siguienteId(productos), ...datosProducto };
      setProductos((productosActuales) => [...productosActuales, nuevoProducto]);
      mostrarAlerta(`Producto "${nombreProducto}" registrado.`);
    }

    setFormProducto(FORM_PRODUCTO_VACIO);
    setVistaActiva("productos");
  };

  /** Abre el formulario de Agregar Producto pre-relleno con los datos del producto a editar */
  const abrirEdicionProducto = (producto) => {
    setIdProductoEditando(producto.id);
    setFormProducto({
      nombre:               producto.nombre,
      marca:                producto.marca,
      unidad:               producto.unidad,
      stockMinimo:          producto.stockMinimo,
      precio:               producto.precio.toFixed(2),
      codigoBarras:         producto.codigoBarras || "",
      modoPrecio:           "unidad",
      precioPorCaja:        "",
      unidadesPorCajaPrecio:"",
    });
    setVistaActiva("nuevo");
  };

  /** Cancela la edición de producto y limpia el estado */
  const cancelarEdicionProducto = () => {
    setIdProductoEditando(null);
    setFormProducto(FORM_PRODUCTO_VACIO);
    setVistaActiva("productos");
  };

  /**
   * Elimina un producto y todos sus lotes y movimientos asociados.
   * Requiere confirmación previa mediante idProductoAEliminar.
   */
  const eliminarProductoConfirmado = () => {
    if (!idProductoAEliminar) return;
    const producto = productos.find((p) => p.id === idProductoAEliminar);
    setLotes((lotesActuales) => lotesActuales.filter((l) => l.productoId !== idProductoAEliminar));
    setMovimientos((movsActuales) => movsActuales.filter((m) => m.productoId !== idProductoAEliminar));
    setProductos((productosActuales) => productosActuales.filter((p) => p.id !== idProductoAEliminar));
    setIdProductoAEliminar(null);
    mostrarAlerta(`Producto "${producto?.nombre}" eliminado.`);
  };

  /* ── Gestión de unidades de medida ──────────────────────────────────── */

  const agregarUnidadMedida = () => {
    const unidadNormalizada = nuevaUnidad.trim();
    if (!unidadNormalizada) return mostrarAlerta("Escribe el nombre de la unidad.", "err");
    if (unidadesMedida.some((u) => u.toLowerCase() === unidadNormalizada.toLowerCase()))
      return mostrarAlerta("Esa unidad ya existe.", "err");
    setUnidadesMedida((lista) => [...lista, unidadNormalizada]);
    setNuevaUnidad("");
    mostrarAlerta(`Unidad "${unidadNormalizada}" agregada.`);
  };

  const guardarEdicionUnidad = (indice) => {
    const textoNormalizado = textoUnidadEditando.trim();
    if (!textoNormalizado) return mostrarAlerta("El nombre no puede estar vacio.", "err");
    if (unidadesMedida.some((u, i) => i !== indice && u.toLowerCase() === textoNormalizado.toLowerCase()))
      return mostrarAlerta("Ya existe una unidad con ese nombre.", "err");
    const nombreAnterior = unidadesMedida[indice];
    setUnidadesMedida((lista) => lista.map((u, i) => i === indice ? textoNormalizado : u));
    // Actualizar productos que usen la unidad renombrada
    setProductos((productosActuales) =>
      productosActuales.map((p) =>
        p.unidad === nombreAnterior ? { ...p, unidad: textoNormalizado } : p
      )
    );
    setIdUnidadEditando(null);
    setTextoUnidadEditando("");
    mostrarAlerta(`Unidad renombrada a "${textoNormalizado}".`);
  };

  const eliminarUnidadMedida = (indice) => {
    const unidadAEliminar = unidadesMedida[indice];
    const productosAfectados = productos.filter((p) => p.unidad === unidadAEliminar).length;
    if (productosAfectados > 0) {
      mostrarAlerta(
        `No se puede eliminar "${unidadAEliminar}" porque ${productosAfectados} producto${productosAfectados > 1 ? "s la usan" : " la usa"}. Cambia su unidad primero.`,
        "err"
      );
      return;
    }
    setUnidadesMedida((lista) => lista.filter((_, i) => i !== indice));
    mostrarAlerta(`Unidad "${unidadAEliminar}" eliminada.`);
  };

  const calcularTotalEntrada = () => {
    if (formEntrada.modo === "cajas")
      return (parseInt(formEntrada.cajas) || 0) * (parseInt(formEntrada.unidadesCaja) || 0);
    return parseInt(formEntrada.cantidad) || 0;
  };

  const registrarEntrada = () => {
    if (!formEntrada.productoId) return mostrarAlerta("Selecciona un producto.", "err");
    const totalUnidades = calcularTotalEntrada();
    if (totalUnidades <= 0)   return mostrarAlerta("La cantidad debe ser mayor a cero.", "err");
    if (!formEntrada.caducidad) return mostrarAlerta("Ingresa la fecha de caducidad del lote.", "err");
    // Advertir si la fecha de caducidad ya pasó (puede ser error de tipeo)
    const hoyIso = new Date().toISOString().slice(0, 10);
    if (formEntrada.caducidad < hoyIso) {
      // Mostrar alerta pero NO bloquear — puede ser una devolución o corrección legítima
      mostrarAlerta("⚠ La fecha de caducidad ya pasó. Verifica que sea correcta antes de continuar.", "err");
      return;
    }
    const producto = productos.find((p) => p.id === parseInt(formEntrada.productoId));
    if (!producto) return mostrarAlerta("Producto no encontrado. Recarga la lista.", "err");
    // Capturar IDs y timestamp ANTES de setState para evitar closures sobre estado desactualizado
    const idNuevoLote       = formEntrada.loteId === "nueva" ? siguienteId(lotes) : parseInt(formEntrada.loteId);
    const idNuevoMovimiento = siguienteId(movimientos);
    const fechaHoraRegistro = obtenerFechaHoraActual();
    if (formEntrada.loteId === "nueva") {
      const nuevoLote = { id:idNuevoLote, productoId:producto.id, cantidad:totalUnidades, fechaCaducidad:formEntrada.caducidad, fechaEntrada:fechaHoraRegistro.slice(0,10) };
      setLotes((lotesActuales) => [...lotesActuales, nuevoLote]);
    } else {
      setLotes((lotesActuales) => lotesActuales.map((l) => l.id === idNuevoLote ? { ...l, cantidad: l.cantidad + totalUnidades } : l));
    }
    const nuevoMovimiento = {
      id: idNuevoMovimiento, productoId: producto.id, loteId: idNuevoLote,
      tipo: "entrada", cantidad: totalUnidades, motivo: formEntrada.motivo,
      fecha: fechaHoraRegistro, modo: formEntrada.modo,
      cajas:        parseInt(formEntrada.cajas)        || undefined,
      unidadesCaja: parseInt(formEntrada.unidadesCaja) || undefined,
    };
    const nombreProducto = producto.nombre;
    setMovimientos((movsActuales) => [nuevoMovimiento, ...movsActuales]);
    setFormEntrada(FORM_ENTRADA_VACIO);
    mostrarAlerta(`Entrada de ${totalUnidades} unidades de "${nombreProducto}" registrada.`);
  };

  /**
   * Registra una salida de inventario.
   * Si se llama sin argumentos, lee del formSalida (flujo manual).
   * Si se pasan argumentos, los usa directamente (flujo escaner).
   * @returns {boolean} true si la operacion fue exitosa
   */
  const registrarSalida = ({
    productoId       = parseInt(formSalida.productoId),
    loteId           = parseInt(formSalida.loteId),
    cantidad         = parseInt(formSalida.cantidad) || 0,
    motivo           = formSalida.motivo,
    limpiarFormulario = true,
  } = {}) => {
    if (!productoId) return mostrarAlerta("Selecciona un producto.", "err");
    if (!loteId)     return mostrarAlerta("Selecciona un lote.", "err");
    if (cantidad <= 0) return mostrarAlerta("Ingresa una cantidad valida.", "err");
    const lote = lotes.find((l) => l.id === loteId);
    if (!lote || cantidad > lote.cantidad) {
      mostrarAlerta(`Stock insuficiente en ese lote. Disponible: ${lote?.cantidad || 0}`, "err");
      return false;
    }
    const producto       = productos.find((p) => p.id === productoId);
    const idMovimiento   = siguienteId(movimientos);   // capturado antes de setState
    const fechaSalida    = obtenerFechaHoraActual();
    const nuevoMovimiento = { id: idMovimiento, productoId, loteId, tipo:"salida", cantidad, motivo, fecha: fechaSalida, modo:"unidades" };
    setLotes((lotesActuales) => lotesActuales.map((l) => l.id === loteId ? { ...l, cantidad: l.cantidad - cantidad } : l));
    setMovimientos((movsActuales) => [nuevoMovimiento, ...movsActuales]);
    if (limpiarFormulario) {
      setFormSalida(FORM_SALIDA_VACIO);
      mostrarAlerta(`Salida de ${cantidad} unidades de "${producto?.nombre}" registrada.`);
    }
    return true;
  };

  /* ── Escaner ────────────────────────────────────────────────────────── */
  const procesarCodigoEscaneado = (codigo) => {
    const producto = productos.find((p) => p.codigoBarras === codigo.trim());
    if (!producto) { setResultadoEscaneo({ error: `Codigo "${codigo}" no encontrado en el sistema.` }); return; }
    const lotesConStock = lotes
      .filter((l) => l.productoId === producto.id && l.cantidad > 0)
      .sort((a, b) => new Date(a.fechaCaducidad) - new Date(b.fechaCaducidad));
    setResultadoEscaneo({ producto, lotesConStock, stockTotal: stockTotalPorProductoId[producto.id] || 0 });
  };

  /**
   * Agrega el producto escaneado al carrito de salidas pendientes.
   * Valida que la cantidad no supere el stock disponible del lote,
   * acumulando si el mismo lote ya esta en el carrito.
   */
  const agregarAlCarritoEscaneo = () => {
    if (!resultadoEscaneo?.producto || !resultadoEscaneo.lotesConStock.length) return;
    if (cantidadScanSalida <= 0) { mostrarAlerta("Ingresa una cantidad valida.", "err"); return; }

    const loteMasProximoAVencer = resultadoEscaneo.lotesConStock[0];
    const itemExistenteEnCarrito = carritoEscaneo.find((item) => item.loteId === loteMasProximoAVencer.id);
    const cantidadYaEnCarrito    = itemExistenteEnCarrito?.cantidad || 0;
    const stockDisponibleLote    = loteMasProximoAVencer.cantidad;

    if (cantidadScanSalida + cantidadYaEnCarrito > stockDisponibleLote) {
      const disponibleRestante = stockDisponibleLote - cantidadYaEnCarrito;
      mostrarAlerta(`Stock insuficiente. Puedes agregar hasta ${disponibleRestante} uds mas de este lote.`, "err");
      return;
    }

    if (itemExistenteEnCarrito) {
      setCarritoEscaneo((carritoActual) =>
        carritoActual.map((item) =>
          item.loteId === loteMasProximoAVencer.id
            ? { ...item, cantidad: item.cantidad + cantidadScanSalida }
            : item
        )
      );
    } else {
      const nuevoItemCarrito = {
        idItem:             generarIdCarrito(),
        productoId:         resultadoEscaneo.producto.id,
        loteId:             loteMasProximoAVencer.id,
        cantidad:           cantidadScanSalida,
        motivo:             motivoScanSalida,
        nombreProducto:     resultadoEscaneo.producto.nombre,
        marcaProducto:      resultadoEscaneo.producto.marca,
        fechaCaducidadLote: loteMasProximoAVencer.fechaCaducidad,
      };
      setCarritoEscaneo((carritoActual) => [...carritoActual, nuevoItemCarrito]);
    }

    setResultadoEscaneo(null);
    setCodigoEscaneado("");
    setCantidadScanSalida(1);
    if (inputScannerRef.current) inputScannerRef.current.focus();
  };

  /**
   * Registra todos los productos acumulados en el carrito de escaneo.
   * Valida el stock de cada item justo antes de registrar para evitar
   * inconsistencias si el stock cambio desde que se agrego al carrito.
   */
  const registrarCarritoCompleto = () => {
    if (carritoEscaneo.length === 0) return;

    // Validar stock de cada item con el estado actual de lotes
    let lotesEnProceso = [...lotes];
    for (const item of carritoEscaneo) {
      const loteEnProceso = lotesEnProceso.find((l) => l.id === item.loteId);
      if (!loteEnProceso || item.cantidad > loteEnProceso.cantidad) {
        mostrarAlerta(`Stock insuficiente para "${item.nombreProducto}". Disponible: ${loteEnProceso?.cantidad || 0}`, "err");
        return;
      }
      // Descontar virtualmente para detectar conflictos entre items del mismo lote
      lotesEnProceso = lotesEnProceso.map((l) =>
        l.id === item.loteId ? { ...l, cantidad: l.cantidad - item.cantidad } : l
      );
    }

    // Aplicar los cambios reales al estado
    let siguienteMovId = siguienteId(movimientos);
    const fechaRegistro = obtenerFechaHoraActual();
    const nuevosMovimientos = carritoEscaneo.map((item) => ({
      id:         siguienteMovId++,
      productoId: item.productoId,
      loteId:     item.loteId,
      tipo:       "salida",
      cantidad:   item.cantidad,
      motivo:     item.motivo,
      fecha:      fechaRegistro,
      modo:       "unidades",
    }));

    setLotes(() => lotesEnProceso);
    setMovimientos((movsActuales) => [...nuevosMovimientos, ...movsActuales]);

    const totalItems    = carritoEscaneo.length;
    const totalUnidades = carritoEscaneo.reduce((suma, item) => suma + item.cantidad, 0);
    mostrarAlerta(`${totalItems} producto${totalItems > 1 ? "s" : ""} registrado${totalItems > 1 ? "s" : ""} — ${totalUnidades} unidades en total.`);

    setCarritoEscaneo([]);
    setResultadoEscaneo(null);
    setCodigoEscaneado("");
    setCantidadScanSalida(1);
    setMotivoScanSalida(MOTIVOS_SALIDA[0]);
  };

  /* ── Edición de movimientos existentes ─────────────────────────────── */

  /**
   * Abre el formulario de edición para un movimiento del historial.
   * Pre-rellena con los valores actuales del movimiento.
   */
  const abrirEdicionMovimiento = (movimiento) => {
    setIdMovimientoEditando(movimiento.id);
    setFormEdicionMovimiento({
      id:               movimiento.id,
      cantidad:         movimiento.cantidad,
      motivo:           movimiento.motivo,
      tipo:             movimiento.tipo,
      cantidadOriginal: movimiento.cantidad,
      loteId:           movimiento.loteId,
    });
  };

  /** Cancela la edición sin guardar cambios */
  const cancelarEdicionMovimiento = () => {
    setIdMovimientoEditando(null);
    setFormEdicionMovimiento(FORM_EDICION_MOVIMIENTO_VACIO);
  };

  /**
   * Guarda los cambios de un movimiento editado.
   *
   * Lógica de stock:
   *   1. Reversa el efecto del movimiento original en el lote
   *   2. Aplica el nuevo efecto con la cantidad corregida
   *   3. Valida que no quede stock negativo
   */
  const guardarEdicionMovimiento = () => {
    const { id, cantidad: cantidadNueva, motivo: motivoNuevo, tipo, cantidadOriginal, loteId } = formEdicionMovimiento;

    const cantidadNuevaNum = parseInt(cantidadNueva);
    if (!cantidadNuevaNum || cantidadNuevaNum <= 0) {
      mostrarAlerta("La cantidad debe ser un número mayor a cero.", "err");
      return;
    }

    // Guard: loteId puede ser null si el movimiento fue registrado antes de que
    // existiera el campo (datos de ejemplo) o si hay corrupción de datos
    if (!loteId) {
      mostrarAlerta("Este movimiento no tiene lote asociado y no puede editarse.", "err");
      return;
    }

    const loteAfectado = lotes.find((l) => l.id === loteId);
    if (!loteAfectado) {
      mostrarAlerta("No se encontró el lote asociado a este movimiento.", "err");
      return;
    }

    // Calcular el stock resultante:
    // Reversar efecto original → aplicar efecto nuevo
    let stockResultante = loteAfectado.cantidad;
    if (tipo === "entrada") {
      // El movimiento original sumó cantidadOriginal → revertir y aplicar nueva
      stockResultante = stockResultante - cantidadOriginal + cantidadNuevaNum;
    } else {
      // El movimiento original restó cantidadOriginal → revertir y aplicar nueva
      stockResultante = stockResultante + cantidadOriginal - cantidadNuevaNum;
    }

    if (stockResultante < 0) {
      mostrarAlerta(
        `La cantidad editada dejaría el lote con stock negativo (${stockResultante}). ` +
        `Máximo permitido para esta corrección: ${loteAfectado.cantidad + cantidadOriginal} uds.`,
        "err"
      );
      return;
    }

    // Aplicar cambios al lote
    setLotes((lotesActuales) =>
      lotesActuales.map((l) =>
        l.id === loteId ? { ...l, cantidad: stockResultante } : l
      )
    );

    // Aplicar cambios al movimiento
    setMovimientos((movsActuales) =>
      movsActuales.map((m) =>
        m.id === id
          ? { ...m, cantidad: cantidadNuevaNum, motivo: motivoNuevo }
          : m
      )
    );

    mostrarAlerta("Movimiento corregido correctamente.");
    cancelarEdicionMovimiento();
  };

  useEffect(() => {
    if (vistaActiva === "escaner" && inputScannerRef.current) inputScannerRef.current.focus();
  }, [vistaActiva]);

  /* ── Estilos de navegacion ──────────────────────────────────────────── */
  /** Cambia de vista y cierra cualquier modal o edición inline abierta */
  const navegarA = (clave) => {
    setVistaActiva(clave);
    setIdProductoAEliminar(null);
    setIdMovimientoEditando(null);
    setFormEdicionMovimiento(FORM_EDICION_MOVIMIENTO_VACIO);
    if (clave !== "nuevo") {
      setIdProductoEditando(null);
      setFormProducto(FORM_PRODUCTO_VACIO);
    }
    // Limpiar formularios de movimiento al navegar a su sección
    if (clave === "entrada") setFormEntrada(FORM_ENTRADA_VACIO);
    if (clave === "salida")  setFormSalida(FORM_SALIDA_VACIO);
  };

  const estiloBotonNav = (clave) => ({
    display:"block", width:"100%", textAlign:"left", padding:"9px 12px", fontSize:13,
    borderRadius:8, border:"none", cursor:"pointer", marginBottom:2,
    background:  vistaActiva === clave ? "#e8e7e0"    : "transparent",
    color:       vistaActiva === clave ? "#1a1a1a"    : "#5f5e5a",
    fontWeight:  vistaActiva === clave ? 500           : 400,
  });

  const totalAlertasSidebar = lotesCaducados.length + lotesPorVencer7d.length + productosStockBajo.length;

  /* ═══════════════════════════════════════════════════════════════════════
     RENDER
  ═══════════════════════════════════════════════════════════════════════ */
  return (
    <div style={{ fontFamily:"'Segoe UI',system-ui,sans-serif", display:"flex", flexDirection:"column", height:"100vh", background:"#f5f4f0" }}>

      <header style={{ background:"#fff", borderBottom:"0.5px solid #e5e4dc", height:50, display:"flex", alignItems:"center", padding:"0 1.25rem", gap:12, flexShrink:0 }}>
        <span style={{ fontSize:15, fontWeight:500 }}>StockAbarrotes</span>
        <span style={{ fontSize:11, background:"#e8e7e0", color:"#888780", padding:"2px 9px", borderRadius:20 }}>v2</span>
        <span style={{ fontSize:11, background:"#EAF3DE", color:"#27500A", padding:"2px 9px", borderRadius:20 }}>Sin internet</span>
        <span style={{ fontSize:11, background:"#e8e7e0", color:"#5f5e5a", padding:"2px 9px", borderRadius:20, fontFamily:"monospace" }}>
          {divisaActual.simbolo} {divisaActual.codigo}
        </span>
        {totalAlertasSidebar > 0 && <span style={{ fontSize:11, background:"#FCEBEB", color:"#791F1F", padding:"2px 9px", borderRadius:20, fontWeight:500 }}>{totalAlertasSidebar} alertas</span>}
      </header>

      <div style={{ display:"flex", flex:1, overflow:"hidden" }}>

        <aside style={{ width:200, minWidth:200, borderRight:"0.5px solid #e5e4dc", padding:"1rem .75rem", background:"#fff", overflowY:"auto", flexShrink:0 }}>
          {SECCIONES_NAVEGACION.map((seccion, indiceSeccion) => (
            <div key={seccion.titulo || "inicio"}>
              <div style={{ fontSize:10, fontWeight:500, color:"#888780", letterSpacing:".07em", textTransform:"uppercase", padding:"0 4px", marginTop: indiceSeccion === 0 ? 0 : 14, marginBottom:5 }}>
                {seccion.titulo || "Inicio"}
              </div>
              {seccion.vistas.map((vista) => (
                <button key={vista.key} onClick={() => navegarA(vista.key)} style={estiloBotonNav(vista.key)}>
                  {vista.label}
                  {vista.badge && (
                    <span style={{ marginLeft:6, fontSize:10, background:vista.badge.bg, color:vista.badge.color, padding:"1px 6px", borderRadius:10 }}>
                      {vista.badge.texto}
                    </span>
                  )}
                </button>
              ))}
            </div>
          ))}
          {totalAlertasSidebar > 0 && (
            <div style={{ marginTop:16, borderTop:"0.5px solid #e5e4dc", paddingTop:12 }}>
              <div style={{ fontSize:10, fontWeight:500, color:"#888780", letterSpacing:".07em", textTransform:"uppercase", padding:"0 4px", marginBottom:7 }}>Alertas</div>
              {lotesCaducados.length > 0   && <div style={{ fontSize:12, background:"#FCEBEB", color:"#791F1F", border:"0.5px solid #F09595", borderRadius:8, padding:"7px 10px", marginBottom:5 }}>{lotesCaducados.length} lote{lotesCaducados.length>1?"s":""} caducado{lotesCaducados.length>1?"s":""}</div>}
              {lotesPorVencer7d.length > 0 && <div style={{ fontSize:12, background:"#FAEEDA", color:"#633806", border:"0.5px solid #EF9F27", borderRadius:8, padding:"7px 10px", marginBottom:5 }}>{lotesPorVencer7d.length} lote{lotesPorVencer7d.length>1?"s":""} vence{lotesPorVencer7d.length>1?"n":""} en 7 dias</div>}
              {productosStockBajo.length > 0 && <div style={{ fontSize:12, background:"#FAEEDA", color:"#633806", border:"0.5px solid #EF9F27", borderRadius:8, padding:"7px 10px" }}>{productosStockBajo.length} producto{productosStockBajo.length>1?"s":""} con stock bajo</div>}
            </div>
          )}
        </aside>

        <main style={{ flex:1, padding:"1.25rem 1.5rem", overflowY:"auto", minWidth:0 }}>
          <MensajeAlerta mensaje={alertaActual?.mensaje} tipo={alertaActual?.tipo} />

          {/* DASHBOARD */}
          {vistaActiva === "dashboard" && (
            <div>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4, flexWrap:"wrap", gap:8 }}>
                <h2 style={{ fontSize:17, fontWeight:500 }}>Resumen inteligente</h2>
                <div style={{ display:"flex", gap:8 }}>
                  <button onClick={hacerRespaldo} style={{ display:"flex", alignItems:"center", gap:6, padding:"7px 14px", borderRadius:8, border:"0.5px solid #d1d0c8", background:"#fff", fontSize:13, cursor:"pointer" }}>
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 2h10M7 4v8M4 9l3 3 3-3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
                    Hacer respaldo
                  </button>
                  <button onClick={exportarResumenPDF} style={{ display:"flex", alignItems:"center", gap:6, padding:"7px 14px", borderRadius:8, border:"0.5px solid #d1d0c8", background:"#fff", fontSize:13, cursor:"pointer" }}>
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 10v2h10v-2M7 2v7M4 6l3 3 3-3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
                    Exportar PDF
                  </button>
                </div>
              </div>
              <p style={{ fontSize:12, color:"#5f5e5a", marginBottom:18 }}>Estado actual del inventario con alertas de caducidad y stock</p>
              <div style={{ display:"flex", gap:10, marginBottom:20, flexWrap:"wrap" }}>
                {[
                  ["Productos registrados", productos.length,          null],
                  ["Lotes caducados",       lotesCaducados.length,     lotesCaducados.length     > 0 ? "#791F1F" : null],
                  ["Vencen en 7 dias",      lotesPorVencer7d.length,   lotesPorVencer7d.length   > 0 ? "#854F0B" : null],
                  ["Vencen en 15 dias",     lotesPorVencer15d.length,  lotesPorVencer15d.length  > 0 ? "#854F0B" : null],
                  ["Stock bajo",            productosStockBajo.length, productosStockBajo.length > 0 ? "#854F0B" : null],
                ].map(([etiqueta, valor, colorAlerta]) => (
                  <div key={etiqueta} style={{ background:"#e8e7e0", borderRadius:8, padding:".85rem 1rem", flex:1, minWidth:90 }}>
                    <div style={{ fontSize:22, fontWeight:500, color: colorAlerta || "#1a1a1a", lineHeight:1.2 }}>{valor}</div>
                    <div style={{ fontSize:11, color:"#5f5e5a", marginTop:2 }}>{etiqueta}</div>
                  </div>
                ))}
              </div>

              {lotesCaducados.length > 0 && (<>
                <div style={{ fontWeight:500, fontSize:13, marginBottom:8, color:"#791F1F" }}>Lotes caducados — requieren accion inmediata</div>
                <div style={{ ...ESTILOS.tarjeta, marginBottom:16 }}><table style={{ width:"100%", borderCollapse:"collapse", tableLayout:"fixed" }}>
                  <thead><tr><th style={ESTILOS.encabezadoTabla}>Producto</th><th style={ESTILOS.encabezadoTabla}>Marca</th><th style={{ ...ESTILOS.encabezadoTabla, width:80 }}>Cant.</th><th style={{ ...ESTILOS.encabezadoTabla, width:100 }}>Caducidad</th><th style={{ ...ESTILOS.encabezadoTabla, width:90 }}>Estado</th></tr></thead>
                  <tbody>{lotesCaducados.map((lote) => (<tr key={lote.id} style={{ background:"rgba(226,75,74,.04)" }}><td style={{ ...ESTILOS.celdaTabla, fontWeight:500 }}>{lote.producto?.nombre}</td><td style={{ ...ESTILOS.celdaTabla, color:"#5f5e5a", fontSize:12 }}>{lote.producto?.marca}</td><td style={ESTILOS.celdaTabla}>{lote.cantidad}</td><td style={{ ...ESTILOS.celdaTabla, fontFamily:"monospace", fontSize:12 }}>{formatearFecha(lote.fechaCaducidad)}</td><td style={ESTILOS.celdaTabla}><EstadoLoteBadge diasRestantesLote={lote.diasRestantes} /></td></tr>))}</tbody>
                </table></div>
              </>)}

              {lotesPorVencer7d.length > 0 && (<>
                <div style={{ fontWeight:500, fontSize:13, marginBottom:8, color:"#633806" }}>Proximos a caducar — dentro de 7 dias</div>
                <div style={{ ...ESTILOS.tarjeta, marginBottom:16 }}><table style={{ width:"100%", borderCollapse:"collapse", tableLayout:"fixed" }}>
                  <thead><tr><th style={ESTILOS.encabezadoTabla}>Producto</th><th style={ESTILOS.encabezadoTabla}>Marca</th><th style={{ ...ESTILOS.encabezadoTabla, width:80 }}>Cant.</th><th style={{ ...ESTILOS.encabezadoTabla, width:100 }}>Caducidad</th><th style={{ ...ESTILOS.encabezadoTabla, width:110 }}>Estado</th></tr></thead>
                  <tbody>{lotesPorVencer7d.map((lote) => (<tr key={lote.id} style={{ background:"rgba(239,159,39,.05)" }}><td style={{ ...ESTILOS.celdaTabla, fontWeight:500 }}>{lote.producto?.nombre}</td><td style={{ ...ESTILOS.celdaTabla, color:"#5f5e5a", fontSize:12 }}>{lote.producto?.marca}</td><td style={ESTILOS.celdaTabla}>{lote.cantidad}</td><td style={{ ...ESTILOS.celdaTabla, fontFamily:"monospace", fontSize:12 }}>{formatearFecha(lote.fechaCaducidad)}</td><td style={ESTILOS.celdaTabla}><EstadoLoteBadge diasRestantesLote={lote.diasRestantes} /></td></tr>))}</tbody>
                </table></div>
              </>)}

              {lotesPorVencer15d.length > 0 && (<>
                <div style={{ fontWeight:500, fontSize:13, marginBottom:8, color:"#5f5e5a" }}>Proximos a caducar — dentro de 15 dias</div>
                <div style={{ ...ESTILOS.tarjeta, marginBottom:16 }}><table style={{ width:"100%", borderCollapse:"collapse", tableLayout:"fixed" }}>
                  <thead><tr><th style={ESTILOS.encabezadoTabla}>Producto</th><th style={ESTILOS.encabezadoTabla}>Marca</th><th style={{ ...ESTILOS.encabezadoTabla, width:80 }}>Cant.</th><th style={{ ...ESTILOS.encabezadoTabla, width:100 }}>Caducidad</th><th style={{ ...ESTILOS.encabezadoTabla, width:110 }}>Estado</th></tr></thead>
                  <tbody>{lotesPorVencer15d.map((lote) => (<tr key={lote.id}><td style={{ ...ESTILOS.celdaTabla, fontWeight:500 }}>{lote.producto?.nombre}</td><td style={{ ...ESTILOS.celdaTabla, color:"#5f5e5a", fontSize:12 }}>{lote.producto?.marca}</td><td style={ESTILOS.celdaTabla}>{lote.cantidad}</td><td style={{ ...ESTILOS.celdaTabla, fontFamily:"monospace", fontSize:12 }}>{formatearFecha(lote.fechaCaducidad)}</td><td style={ESTILOS.celdaTabla}><EstadoLoteBadge diasRestantesLote={lote.diasRestantes} /></td></tr>))}</tbody>
                </table></div>
              </>)}

              {productosStockBajo.length > 0 && (<>
                <div style={{ fontWeight:500, fontSize:13, marginBottom:8 }}>Productos con stock bajo</div>
                <div style={ESTILOS.tarjeta}><table style={{ width:"100%", borderCollapse:"collapse", tableLayout:"fixed" }}>
                  <thead><tr><th style={ESTILOS.encabezadoTabla}>Producto</th><th style={ESTILOS.encabezadoTabla}>Marca</th><th style={{ ...ESTILOS.encabezadoTabla, width:90 }}>Stock actual</th><th style={{ ...ESTILOS.encabezadoTabla, width:80 }}>Minimo</th></tr></thead>
                  <tbody>{productosStockBajo.map((producto) => { const stockActual = stockTotalPorProductoId[producto.id]||0; return (<tr key={producto.id} style={{ background:"rgba(239,159,39,.05)" }}><td style={{ ...ESTILOS.celdaTabla, fontWeight:500 }}>{producto.nombre}</td><td style={{ ...ESTILOS.celdaTabla, color:"#5f5e5a", fontSize:12 }}>{producto.marca}</td><td style={{ ...ESTILOS.celdaTabla, fontWeight:500, color: stockActual===0?"#791F1F":"#633806" }}>{stockActual}</td><td style={{ ...ESTILOS.celdaTabla, color:"#5f5e5a" }}>{producto.stockMinimo}</td></tr>); })}</tbody>
                </table></div>
              </>)}

              {totalAlertasSidebar === 0 && lotesPorVencer15d.length === 0 && (
                <div style={{ background:"#EAF3DE", border:"0.5px solid #97C459", borderRadius:10, padding:"20px 16px", textAlign:"center", color:"#27500A" }}>
                  <div style={{ fontSize:22, fontWeight:500, marginBottom:4 }}>
                    {productos.length === 0 ? "Bienvenido a StockAbarrotes" : "Todo en orden"}
                  </div>
                  <div style={{ fontSize:13 }}>
                    {productos.length === 0
                      ? "Comienza agregando tus productos en Configuracion → Agregar producto."
                      : "No hay lotes caducados ni stock bajo en este momento."}
                  </div>
                  {productos.length === 0 && (
                    <button onClick={() => navegarA("nuevo")}
                      style={{ marginTop:14, padding:"8px 22px", borderRadius:8, border:"0.5px solid #27500A", background:"transparent", fontSize:13, fontWeight:500, color:"#27500A", cursor:"pointer" }}>
                      + Agregar primer producto
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {/* PRODUCTOS */}
          {vistaActiva === "productos" && (
            <div>
              {idProductoAEliminar && (() => {
                const pa = productos.find((p) => p.id === idProductoAEliminar);
                const nl = lotes.filter((l) => l.productoId === idProductoAEliminar).length;
                const nm = movimientos.filter((m) => m.productoId === idProductoAEliminar).length;
                return (
                  <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.35)", zIndex:500, display:"flex", alignItems:"center", justifyContent:"center" }}>
                    <div style={{ background:"#fff", borderRadius:12, padding:"1.5rem", maxWidth:420, width:"90%", boxShadow:"0 8px 32px rgba(0,0,0,.18)" }}>
                      <div style={{ fontSize:16, fontWeight:500, marginBottom:8 }}>¿Eliminar producto?</div>
                      <div style={{ fontSize:13, color:"#5f5e5a", marginBottom:16 }}>
                        <strong style={{ color:"#1a1a1a" }}>{pa?.nombre} — {pa?.marca}</strong><br/>
                        {nl > 0 && <span style={{ color:"#791F1F" }}>⚠ Se eliminaran {nl} lote{nl>1?"s":""} asociado{nl>1?"s":""}.<br/></span>}
                        {nm > 0 && <span style={{ color:"#791F1F" }}>⚠ Se eliminaran {nm} movimiento{nm>1?"s":""} del historial.<br/></span>}
                        {nl === 0 && nm === 0 && <span>Sin lotes ni movimientos asociados.</span>}
                      </div>
                      <div style={{ display:"flex", gap:8, justifyContent:"flex-end" }}>
                        <button onClick={() => setIdProductoAEliminar(null)} style={{ padding:"8px 16px", borderRadius:8, border:"0.5px solid #e5e4dc", background:"transparent", fontSize:13, color:"#5f5e5a", cursor:"pointer" }}>Cancelar</button>
                        <button onClick={eliminarProductoConfirmado} style={{ padding:"8px 16px", borderRadius:8, border:"0.5px solid #F09595", background:"#FCEBEB", fontSize:13, fontWeight:500, color:"#791F1F", cursor:"pointer" }}>Si, eliminar</button>
                      </div>
                    </div>
                  </div>
                );
              })()}
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:14, flexWrap:"wrap", gap:8 }}>
                <div><h2 style={{ fontSize:17, fontWeight:500, marginBottom:3 }}>Productos</h2><p style={{ fontSize:12, color:"#5f5e5a" }}>{productosFiltrados.length} de {productos.length}</p></div>
                <button onClick={() => { setIdProductoEditando(null); setFormProducto(FORM_PRODUCTO_VACIO); setVistaActiva("nuevo"); }} style={{ padding:"7px 14px", borderRadius:8, border:"0.5px solid #d1d0c8", background:"#fff", fontSize:13, cursor:"pointer" }}>+ Agregar producto</button>
              </div>
              <input placeholder="Buscar por nombre o marca..." value={textoBusquedaProductos} onChange={(e) => setTextoBusquedaProductos(e.target.value)} style={{ ...ESTILOS.inputBase, marginBottom:14 }} />
              {productosFiltrados.length === 0 && !textoBusquedaProductos && (
                <div style={{ ...ESTILOS.tarjeta, padding:"2.5rem", textAlign:"center", color:"#888780", marginBottom:14 }}>
                  <div style={{ fontSize:32, marginBottom:10 }}>📦</div>
                  <div style={{ fontSize:14, fontWeight:500, color:"#5f5e5a", marginBottom:6 }}>Sin productos registrados</div>
                  <div style={{ fontSize:12, marginBottom:16 }}>Agrega el primer producto desde Configuracion → Agregar producto</div>
                  <button onClick={() => navegarA("nuevo")}
                    style={{ padding:"8px 20px", borderRadius:8, border:"0.5px solid #97C459", background:"#EAF3DE", fontSize:13, fontWeight:500, color:"#27500A", cursor:"pointer" }}>
                    + Agregar primer producto
                  </button>
                </div>
              )}
              <div style={ESTILOS.tarjeta}><table style={{ width:"100%", borderCollapse:"collapse", tableLayout:"fixed" }}>
                <thead><tr>
                  <th style={ESTILOS.encabezadoTabla}>Nombre</th>
                  <th style={{ ...ESTILOS.encabezadoTabla, width:110 }}>Marca</th>
                  <th style={{ ...ESTILOS.encabezadoTabla, width:65 }}>Unidad</th>
                  <th style={{ ...ESTILOS.encabezadoTabla, width:70 }}>Stock</th>
                  <th style={{ ...ESTILOS.encabezadoTabla, width:50 }}>Min.</th>
                  <th style={{ ...ESTILOS.encabezadoTabla, width:80 }}>Precio</th>
                  <th style={{ ...ESTILOS.encabezadoTabla, width:70 }}>Acciones</th>
                </tr></thead>
                <tbody>{productosFiltrados.map((producto) => {
                  const stockActual = stockTotalPorProductoId[producto.id] || 0;
                  const fondoFila   = stockActual === 0 ? "rgba(226,75,74,.04)" : stockActual < producto.stockMinimo ? "rgba(239,159,39,.05)" : "transparent";
                  return (
                    <tr key={producto.id} style={{ background:fondoFila }}>
                      <td style={{ ...ESTILOS.celdaTabla, fontWeight:500 }}>{producto.nombre}</td>
                      <td style={{ ...ESTILOS.celdaTabla, color:"#5f5e5a", fontSize:12 }}>{producto.marca}</td>
                      <td style={{ ...ESTILOS.celdaTabla, fontSize:12, color:"#5f5e5a" }}>{producto.unidad}</td>
                      <td style={{ ...ESTILOS.celdaTabla, fontWeight:500 }}>{stockActual}</td>
                      <td style={{ ...ESTILOS.celdaTabla, color:"#5f5e5a" }}>{producto.stockMinimo}</td>
                      <td style={ESTILOS.celdaTabla}>{fmtPrecio(producto.precio)}</td>
                      <td style={{ ...ESTILOS.celdaTabla, padding:"6px 8px" }}>
                        <div style={{ display:"flex", gap:4 }}>
                          <button onClick={() => abrirEdicionProducto(producto)} title="Editar"
                            style={{ border:"none", background:"transparent", cursor:"pointer", fontSize:13, color:"#5f5e5a", padding:"3px 5px", borderRadius:4 }}>✏</button>
                          <button onClick={() => setIdProductoAEliminar(producto.id)} title="Eliminar"
                            style={{ border:"none", background:"transparent", cursor:"pointer", fontSize:13, color:"#888780", padding:"3px 5px", borderRadius:4 }}>🗑</button>
                        </div>
                      </td>
                    </tr>
                  );
                })}</tbody>
              </table></div>
            </div>
          )}

                    {/* NUEVO / EDITAR PRODUCTO */}
          {vistaActiva === "nuevo" && (
            <div style={{ maxWidth:480 }}>
              <h2 style={{ fontSize:17, fontWeight:500, marginBottom:4 }}>
                {idProductoEditando ? "Editar producto" : "Agregar producto nuevo"}
              </h2>
              <p style={{ fontSize:12, color:"#5f5e5a", marginBottom:18 }}>
                {idProductoEditando
                  ? "Modifica los datos del producto. El stock no cambia desde aqui."
                  : "El stock se agrega mediante el modulo de entradas, no aqui."}
              </p>
              <div style={ESTILOS.formulario}>
                <CampoFormulario etiqueta="Nombre del producto" obligatorio>
                  <input value={formProducto.nombre} onChange={(e) => setFormProducto((f) => ({ ...f, nombre:e.target.value }))} placeholder="Ej: Arroz" style={ESTILOS.inputBase} />
                </CampoFormulario>
                <CampoFormulario etiqueta="Marca" obligatorio>
                  <input value={formProducto.marca} onChange={(e) => setFormProducto((f) => ({ ...f, marca:e.target.value }))} placeholder="Ej: La Moderna" style={ESTILOS.inputBase} />
                </CampoFormulario>
                <div style={{ display:"flex", gap:10 }}>
                  <div style={{ flex:1 }}>
                    <CampoFormulario etiqueta="Unidad de medida">
                      <select value={formProducto.unidad} onChange={(e) => setFormProducto((f) => ({ ...f, unidad:e.target.value }))} style={ESTILOS.inputBase}>
                        {unidadesMedida.map((u) => <option key={u}>{u}</option>)}
                      </select>
                    </CampoFormulario>
                  </div>
                  <div style={{ flex:1 }}>
                    <CampoFormulario etiqueta="Stock minimo de alerta">
                      <input type="number" min={0} value={formProducto.stockMinimo} onChange={(e) => setFormProducto((f) => ({ ...f, stockMinimo:e.target.value }))} style={ESTILOS.inputBase} />
                    </CampoFormulario>
                  </div>
                </div>

                {/* Precio — toggle entre precio unitario y precio por caja */}
                <CampoFormulario etiqueta={`Precio (${divisaActual.simbolo})`} obligatorio>
                  <div style={{ display:"flex", gap:8, marginBottom:10 }}>
                    {[["unidad","Precio unitario"],["caja","Precio por caja"]].map(([modo, etiq]) => (
                      <button key={modo} onClick={() => setFormProducto((f) => ({ ...f, modoPrecio:modo }))}
                        style={{ flex:1, padding:"8px 0", borderRadius:8, fontSize:13, cursor:"pointer",
                          fontWeight: formProducto.modoPrecio===modo ? 500 : 400,
                          background: formProducto.modoPrecio===modo ? "#e8e7e0" : "transparent",
                          border:     formProducto.modoPrecio===modo ? "0.5px solid #888780" : "0.5px solid #e5e4dc",
                          color:      formProducto.modoPrecio===modo ? "#1a1a1a" : "#5f5e5a" }}>
                        {etiq}
                      </button>
                    ))}
                  </div>

                  {formProducto.modoPrecio === "unidad" ? (
                    <input type="number" min={0} step="0.01" placeholder="0.00"
                      value={formProducto.precio}
                      onChange={(e) => setFormProducto((f) => ({ ...f, precio:e.target.value }))}
                      style={ESTILOS.inputBase} />
                  ) : (
                    <div style={{ background:"#f5f4f0", borderRadius:8, padding:12 }}>
                      <div style={{ fontSize:12, color:"#5f5e5a", marginBottom:10 }}>El precio unitario se calcula automaticamente</div>
                      <div style={{ display:"flex", gap:10, alignItems:"center", marginBottom:8 }}>
                        <div style={{ flex:1 }}>
                          <label style={{ fontSize:11, color:"#5f5e5a", display:"block", marginBottom:4 }}>Precio de la caja ({divisaActual.simbolo})</label>
                          <input type="number" min={0} step="0.01" placeholder="0.00"
                            value={formProducto.precioPorCaja}
                            onChange={(e) => setFormProducto((f) => ({ ...f, precioPorCaja:e.target.value }))}
                            style={ESTILOS.inputBase} />
                        </div>
                        <div style={{ fontSize:16, color:"#888780", paddingTop:16 }}>÷</div>
                        <div style={{ flex:1 }}>
                          <label style={{ fontSize:11, color:"#5f5e5a", display:"block", marginBottom:4 }}>Unidades en la caja</label>
                          <input type="number" min={1} placeholder="0"
                            value={formProducto.unidadesPorCajaPrecio}
                            onChange={(e) => setFormProducto((f) => ({ ...f, unidadesPorCajaPrecio:e.target.value }))}
                            style={ESTILOS.inputBase} />
                        </div>
                        <div style={{ fontSize:16, color:"#888780", paddingTop:16 }}>=</div>
                        <div style={{ flex:1 }}>
                          <label style={{ fontSize:11, color:"#5f5e5a", display:"block", marginBottom:4 }}>Precio unitario</label>
                          <div style={{ padding:"8px 10px", background:"#e8e7e0", borderRadius:8, fontSize:14, fontWeight:500, minHeight:36, color:"#27500A" }}>
                            {formProducto.precioPorCaja && formProducto.unidadesPorCajaPrecio && parseInt(formProducto.unidadesPorCajaPrecio) > 0
                              ? fmtPrecio(parseFloat(formProducto.precioPorCaja) / parseInt(formProducto.unidadesPorCajaPrecio))
                              : "—"}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CampoFormulario>

                <CampoFormulario etiqueta="Codigo de barras (opcional)">
                  <input value={formProducto.codigoBarras} onChange={(e) => setFormProducto((f) => ({ ...f, codigoBarras:e.target.value }))} placeholder="750123..." style={ESTILOS.inputBase} />
                </CampoFormulario>

                <div style={{ display:"flex", gap:10, marginTop:4 }}>
                  <button onClick={guardarProducto} style={{ flex:1, padding:10, borderRadius:8, border:"0.5px solid #d1d0c8", background:"#e8e7e0", fontSize:13, fontWeight:500, cursor:"pointer" }}>
                    {idProductoEditando ? "Guardar cambios" : "Guardar producto"}
                  </button>
                  <button onClick={cancelarEdicionProducto} style={{ padding:"10px 14px", borderRadius:8, border:"0.5px solid #e5e4dc", background:"transparent", fontSize:13, color:"#5f5e5a", cursor:"pointer" }}>Cancelar</button>
                </div>
              </div>
            </div>
          )}

          {/* LOTES */}
          {vistaActiva === "lotes" && (
            <div>
              <h2 style={{ fontSize:17, fontWeight:500, marginBottom:4 }}>Lotes y caducidades</h2>
              <p style={{ fontSize:12, color:"#5f5e5a", marginBottom:18 }}>Todos los lotes ordenados del mas proximo a caducar al mas lejano</p>
              <div style={ESTILOS.tarjeta}><table style={{ width:"100%", borderCollapse:"collapse", tableLayout:"fixed" }}>
                <thead><tr><th style={ESTILOS.encabezadoTabla}>Producto</th><th style={{ ...ESTILOS.encabezadoTabla, width:110 }}>Marca</th><th style={{ ...ESTILOS.encabezadoTabla, width:70 }}>Cantidad</th><th style={{ ...ESTILOS.encabezadoTabla, width:100 }}>Caducidad</th><th style={{ ...ESTILOS.encabezadoTabla, width:95 }}>Entrada</th><th style={{ ...ESTILOS.encabezadoTabla, width:115 }}>Estado</th></tr></thead>
                <tbody>{[...lotesEnriquecidos].sort((a,b) => a.diasRestantes - b.diasRestantes).map((lote) => {
                  const fondoFila = lote.diasRestantes<0?"rgba(226,75,74,.04)":lote.diasRestantes<=7?"rgba(226,75,74,.03)":lote.diasRestantes<=15?"rgba(239,159,39,.04)":"transparent";
                  return (<tr key={lote.id} style={{ background:fondoFila }}><td style={{ ...ESTILOS.celdaTabla, fontWeight:500 }}>{lote.producto?.nombre}</td><td style={{ ...ESTILOS.celdaTabla, color:"#5f5e5a", fontSize:12 }}>{lote.producto?.marca}</td><td style={{ ...ESTILOS.celdaTabla, fontWeight:500, color:lote.cantidad===0?"#888780":"inherit" }}>{lote.cantidad}</td><td style={{ ...ESTILOS.celdaTabla, fontFamily:"monospace", fontSize:12 }}>{formatearFecha(lote.fechaCaducidad)}</td><td style={{ ...ESTILOS.celdaTabla, fontFamily:"monospace", fontSize:11, color:"#888780" }}>{formatearFecha(lote.fechaEntrada)}</td><td style={ESTILOS.celdaTabla}><EstadoLoteBadge diasRestantesLote={lote.diasRestantes} /></td></tr>);
                })}</tbody>
              </table></div>
            </div>
          )}

          {/* ENTRADA */}
          {vistaActiva === "entrada" && (() => {
            const totalUnidadesPreview     = calcularTotalEntrada();
            const productoSeleccionado     = formEntrada.productoId ? productos.find((p) => p.id === parseInt(formEntrada.productoId)) : null;
            const mostrarPreviewEntrada    = productoSeleccionado && totalUnidadesPreview > 0 && formEntrada.caducidad;
            return (
              <div style={{ maxWidth:480 }}>
                <h2 style={{ fontSize:17, fontWeight:500, marginBottom:4 }}>Registrar entrada de mercancia</h2>
                <p style={{ fontSize:12, color:"#5f5e5a", marginBottom:18 }}>Puedes ingresar por cajas o por unidades. El total se calcula automaticamente.</p>
                <div style={ESTILOS.formulario}>
                  <CampoFormulario etiqueta="Producto" obligatorio>
                    <SelectorProductoBuscable
                      productos={productos}
                      stockPorProductoId={stockTotalPorProductoId}
                      productoIdSeleccionado={formEntrada.productoId}
                      alCambiar={(id) => setFormEntrada((f) => ({ ...f, productoId: id, loteId: "nueva" }))}
                      placeholder="Buscar producto por nombre o marca..."
                    />
                  </CampoFormulario>
                  <CampoFormulario etiqueta="Modo de registro">
                    <div style={{ display:"flex", gap:8 }}>
                      {["unidades","cajas"].map((modo) => (
                        <button key={modo} onClick={() => setFormEntrada((f) => ({ ...f, modo }))}
                          style={{ flex:1, padding:"8px 0", borderRadius:8, fontSize:13, cursor:"pointer", fontWeight:formEntrada.modo===modo?500:400, background:formEntrada.modo===modo?"#e8e7e0":"transparent", border:formEntrada.modo===modo?"0.5px solid #888780":"0.5px solid #e5e4dc", color:formEntrada.modo===modo?"#1a1a1a":"#5f5e5a" }}>
                          {modo === "unidades" ? "Por unidades" : "Por cajas"}
                        </button>
                      ))}
                    </div>
                  </CampoFormulario>
                  {formEntrada.modo === "unidades" ? (
                    <CampoFormulario etiqueta="Cantidad de unidades" obligatorio><input type="number" min={1} placeholder="0" value={formEntrada.cantidad} onChange={(e) => setFormEntrada((f) => ({ ...f, cantidad:e.target.value }))} style={ESTILOS.inputBase} /></CampoFormulario>
                  ) : (
                    <div style={{ background:"#f5f4f0", borderRadius:8, padding:12, marginBottom:13 }}>
                      <div style={{ fontSize:12, color:"#5f5e5a", marginBottom:10 }}>Calculo automatico por cajas</div>
                      <div style={{ display:"flex", gap:10, alignItems:"center" }}>
                        <div style={{ flex:1 }}><label style={{ fontSize:11, color:"#5f5e5a", display:"block", marginBottom:4 }}>Numero de cajas</label><input type="number" min={1} placeholder="0" value={formEntrada.cajas} onChange={(e) => setFormEntrada((f) => ({ ...f, cajas:e.target.value }))} style={ESTILOS.inputBase} /></div>
                        <div style={{ fontSize:18, color:"#888780", paddingTop:16 }}>×</div>
                        <div style={{ flex:1 }}><label style={{ fontSize:11, color:"#5f5e5a", display:"block", marginBottom:4 }}>Unidades por caja</label><input type="number" min={1} placeholder="0" value={formEntrada.unidadesCaja} onChange={(e) => setFormEntrada((f) => ({ ...f, unidadesCaja:e.target.value }))} style={ESTILOS.inputBase} /></div>
                        <div style={{ fontSize:18, color:"#888780", paddingTop:16 }}>=</div>
                        <div style={{ flex:1 }}><label style={{ fontSize:11, color:"#5f5e5a", display:"block", marginBottom:4 }}>Total unidades</label><div style={{ padding:"8px 10px", background:"#e8e7e0", borderRadius:8, fontSize:14, fontWeight:500, minHeight:36 }}>{totalUnidadesPreview||"—"}</div></div>
                      </div>
                    </div>
                  )}
                  <div style={{ display:"flex", gap:10 }}>
                    <div style={{ flex:1 }}><CampoFormulario etiqueta="Fecha de caducidad del lote" obligatorio><input type="date" value={formEntrada.caducidad} onChange={(e) => setFormEntrada((f) => ({ ...f, caducidad:e.target.value }))} style={ESTILOS.inputBase} /></CampoFormulario></div>
                    <div style={{ flex:1 }}><CampoFormulario etiqueta="Lote existente (opcional)"><select value={formEntrada.loteId} onChange={(e) => setFormEntrada((f) => ({ ...f, loteId:e.target.value }))} style={ESTILOS.inputBase}><option value="nueva">Crear lote nuevo</option>{lotesExistentesProductoEntrada.map((l) => <option key={l.id} value={l.id}>Lote {l.id} — cad. {formatearFecha(l.fechaCaducidad)} ({l.cantidad} uds)</option>)}</select></CampoFormulario></div>
                  </div>
                  <CampoFormulario etiqueta="Motivo de entrada"><select value={formEntrada.motivo} onChange={(e) => setFormEntrada((f) => ({ ...f, motivo:e.target.value }))} style={ESTILOS.inputBase}>{MOTIVOS_ENTRADA.map((m) => <option key={m}>{m}</option>)}</select></CampoFormulario>
                  {mostrarPreviewEntrada && (
                    <div style={{ background:"#EAF3DE", border:"0.5px solid #97C459", borderRadius:8, padding:"9px 11px", fontSize:12, color:"#27500A", marginBottom:12 }}>
                      Se agregaran <strong>{totalUnidadesPreview}</strong> unidades de <strong>{productoSeleccionado.nombre} — {productoSeleccionado.marca}</strong>{formEntrada.modo==="cajas"?` (${formEntrada.cajas} cajas × ${formEntrada.unidadesCaja} uds)`:""}.&nbsp;Caducidad: <strong>{formatearFecha(formEntrada.caducidad)}</strong>.
                    </div>
                  )}
                  <button onClick={registrarEntrada} style={{ width:"100%", padding:10, borderRadius:8, border:"0.5px solid #97C459", background:"#EAF3DE", fontSize:13, fontWeight:500, color:"#27500A", cursor:"pointer" }}>Registrar entrada</button>
                </div>
              </div>
            );
          })()}

          {/* SALIDA */}
          {vistaActiva === "salida" && (() => {
            const loteSeleccionado     = formSalida.loteId ? lotes.find((l) => l.id === parseInt(formSalida.loteId)) : null;
            const cantidadSalida       = parseInt(formSalida.cantidad) || 0;
            const stockRestante        = loteSeleccionado ? loteSeleccionado.cantidad - cantidadSalida : 0;
            const mostrarPreviewSalida = loteSeleccionado && cantidadSalida > 0;
            return (
              <div style={{ maxWidth:460 }}>
                <h2 style={{ fontSize:17, fontWeight:500, marginBottom:4 }}>Registrar salida de mercancia</h2>
                <p style={{ fontSize:12, color:"#5f5e5a", marginBottom:18 }}>Selecciona el producto y el lote especifico a descontar.</p>
                <div style={ESTILOS.formulario}>
                  <CampoFormulario etiqueta="Producto" obligatorio>
                    <SelectorProductoBuscable
                      productos={productos}
                      stockPorProductoId={stockTotalPorProductoId}
                      productoIdSeleccionado={formSalida.productoId}
                      alCambiar={(id) => setFormSalida((f) => ({ ...f, productoId: id, loteId: "" }))}
                      placeholder="Buscar producto por nombre o marca..."
                    />
                  </CampoFormulario>
                  {formSalida.productoId && (
                    <CampoFormulario etiqueta="Lote a descontar" obligatorio>
                      <select value={formSalida.loteId} onChange={(e) => setFormSalida((f) => ({ ...f, loteId:e.target.value }))} style={ESTILOS.inputBase}>
                        <option value="">-- Selecciona un lote --</option>
                        {lotesDisponiblesParaSalida.map((lote) => (<option key={lote.id} value={lote.id}>Lote {lote.id} — cad. {formatearFecha(lote.fechaCaducidad)} — {lote.cantidad} uds{lote.diasRestantes<0?" [CADUCADO]":lote.diasRestantes<=7?" [VENCE PRONTO]":""}</option>))}
                      </select>
                      {lotesDisponiblesParaSalida.length === 0 && <div style={{ fontSize:12, color:"#791F1F", marginTop:5 }}>Sin lotes disponibles para este producto.</div>}
                    </CampoFormulario>
                  )}
                  <CampoFormulario etiqueta="Cantidad que sale" obligatorio><input type="number" min={1} placeholder="0" value={formSalida.cantidad} onChange={(e) => setFormSalida((f) => ({ ...f, cantidad:e.target.value }))} style={ESTILOS.inputBase} /></CampoFormulario>
                  <CampoFormulario etiqueta="Motivo de salida"><select value={formSalida.motivo} onChange={(e) => setFormSalida((f) => ({ ...f, motivo:e.target.value }))} style={ESTILOS.inputBase}>{MOTIVOS_SALIDA.map((m) => <option key={m}>{m}</option>)}</select></CampoFormulario>
                  {mostrarPreviewSalida && (
                    <div style={{ background:stockRestante<0?"#FCEBEB":"#FAEEDA", border:`0.5px solid ${stockRestante<0?"#F09595":"#EF9F27"}`, borderRadius:8, padding:"9px 11px", fontSize:12, color:stockRestante<0?"#791F1F":"#633806", marginBottom:12 }}>
                      {stockRestante < 0 ? <>Stock insuficiente. El lote solo tiene <strong>{loteSeleccionado.cantidad}</strong> unidades.</> : <>El lote pasara de <strong>{loteSeleccionado.cantidad}</strong> a <strong>{stockRestante}</strong> unidades.</>}
                    </div>
                  )}
                  <button onClick={() => registrarSalida()} style={{ width:"100%", padding:10, borderRadius:8, border:"0.5px solid #F09595", background:"#FCEBEB", fontSize:13, fontWeight:500, color:"#791F1F", cursor:"pointer" }}>Registrar salida</button>
                </div>
              </div>
            );
          })()}

          {/* ESCANER */}
          {vistaActiva === "escaner" && (
            <div style={{ maxWidth:700 }}>
              <h2 style={{ fontSize:17, fontWeight:500, marginBottom:4 }}>Escaner de productos</h2>
              <p style={{ fontSize:12, color:"#5f5e5a", marginBottom:18 }}>Escanea el codigo de barras o QR para registrar una salida sin buscar manualmente.</p>
              <div style={{ background:"#E6F1FB", border:"0.5px solid #378ADD", borderRadius:10, padding:"12px 14px", marginBottom:16, fontSize:12, color:"#0C447C" }}>
                Conecta un lector de codigo de barras USB. El lector envia el codigo directamente al campo de abajo. Tambien puedes escribirlo a mano para pruebas.
              </div>
              <div style={ESTILOS.formulario}>
                <label style={{ display:"block", fontSize:12, color:"#5f5e5a", marginBottom:7 }}>Codigo de barras o QR</label>
                <div style={{ display:"flex", gap:8, marginBottom:16 }}>
                  <input ref={inputScannerRef} value={codigoEscaneado} onChange={(e) => setCodigoEscaneado(e.target.value)} onKeyDown={(e) => { if (e.key==="Enter" && codigoEscaneado.trim()) procesarCodigoEscaneado(codigoEscaneado); }}
                    placeholder="Escanea o escribe el codigo..."
                    style={{ flex:1, padding:"10px 12px", border:"2px solid #378ADD", borderRadius:8, fontSize:14, background:"#E6F1FB" }} />
                  <button onClick={() => codigoEscaneado.trim() && procesarCodigoEscaneado(codigoEscaneado)} style={{ padding:"10px 16px", borderRadius:8, border:"0.5px solid #378ADD", background:"#E6F1FB", color:"#0C447C", fontSize:13, fontWeight:500, cursor:"pointer" }}>Buscar</button>
                </div>
                <div style={{ marginBottom:16 }}>
                  <div style={{ fontSize:11, color:"#888780", marginBottom:6 }}>Codigos de prueba (haz clic para simular escaneo):</div>
                  <div style={{ display:"flex", flexWrap:"wrap", gap:6 }}>
                    {productos.filter((p) => p.codigoBarras).map((p) => (
                      <button key={p.id} onClick={() => { setCodigoEscaneado(p.codigoBarras); procesarCodigoEscaneado(p.codigoBarras); }}
                        style={{ fontSize:11, padding:"4px 9px", borderRadius:6, border:"0.5px solid #d1d0c8", background:"#f5f4f0", cursor:"pointer", color:"#5f5e5a", fontFamily:"monospace" }}>
                        {p.codigoBarras} ({p.nombre})
                      </button>
                    ))}
                  </div>
                </div>
                {resultadoEscaneo?.error && (
                  <div style={{ background:"#FCEBEB", border:"0.5px solid #F09595", borderRadius:8, padding:"12px 14px", color:"#791F1F", fontSize:13 }}>
                    {resultadoEscaneo.error}
                  </div>
                )}

                {resultadoEscaneo?.producto && (
                  <div style={{ background:"#EAF3DE", border:"0.5px solid #97C459", borderRadius:8, padding:"12px 14px", marginBottom:12 }}>
                    <div style={{ fontSize:14, fontWeight:500, color:"#27500A", marginBottom:4 }}>
                      {resultadoEscaneo.producto.nombre} — {resultadoEscaneo.producto.marca}
                    </div>
                    <div style={{ fontSize:12, color:"#3B6D11" }}>
                      Stock disponible: <strong>{resultadoEscaneo.stockTotal}</strong> uds
                      {resultadoEscaneo.lotesConStock.length > 0 && (
                        <span style={{ marginLeft:8 }}>· Lote {resultadoEscaneo.lotesConStock[0].id} — cad. {formatearFecha(resultadoEscaneo.lotesConStock[0].fechaCaducidad)}</span>
                      )}
                    </div>
                    {resultadoEscaneo.lotesConStock.length === 0 ? (
                      <div style={{ marginTop:8, fontSize:12, color:"#791F1F" }}>Sin stock disponible para este producto.</div>
                    ) : (
                      <div style={{ display:"flex", gap:10, alignItems:"flex-end", marginTop:10 }}>
                        <div style={{ flex:1 }}>
                          <label style={{ fontSize:11, color:"#5f5e5a", display:"block", marginBottom:4 }}>Cantidad</label>
                          <input type="number" min={1} max={resultadoEscaneo.lotesConStock[0].cantidad}
                            value={cantidadScanSalida}
                            onChange={(e) => setCantidadScanSalida(parseInt(e.target.value) || 1)}
                            style={{ ...ESTILOS.inputBase, padding:"7px 10px", fontSize:14 }}
                          />
                        </div>
                        <div style={{ flex:1 }}>
                          <label style={{ fontSize:11, color:"#5f5e5a", display:"block", marginBottom:4 }}>Motivo</label>
                          <select value={motivoScanSalida} onChange={(e) => setMotivoScanSalida(e.target.value)}
                            style={{ ...ESTILOS.inputBase, padding:"7px 10px" }}>
                            {MOTIVOS_SALIDA.map((m) => <option key={m}>{m}</option>)}
                          </select>
                        </div>
                        <button onClick={agregarAlCarritoEscaneo}
                          style={{ padding:"7px 16px", borderRadius:8, border:"0.5px solid #97C459", background:"#EAF3DE", fontSize:13, fontWeight:500, color:"#27500A", cursor:"pointer", whiteSpace:"nowrap" }}>
                          + Agregar
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Carrito de salidas acumuladas */}
                {carritoEscaneo.length > 0 && (
                  <div>
                    <div style={{ fontSize:13, fontWeight:500, marginBottom:8, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                      <span>Productos en esta transaccion ({carritoEscaneo.length})</span>
                      <span style={{ fontSize:12, color:"#5f5e5a" }}>
                        {carritoEscaneo.reduce((s, i) => s + i.cantidad, 0)} unidades en total
                      </span>
                    </div>
                    <div style={{ ...ESTILOS.tarjeta, marginBottom:12 }}>
                      <table style={{ width:"100%", borderCollapse:"collapse", tableLayout:"fixed" }}>
                        <thead><tr>
                          <th style={ESTILOS.encabezadoTabla}>Producto</th>
                          <th style={{ ...ESTILOS.encabezadoTabla, width:90 }}>Cantidad</th>
                          <th style={{ ...ESTILOS.encabezadoTabla, width:90 }}>Cad. lote</th>
                          <th style={{ ...ESTILOS.encabezadoTabla, width:110 }}>Motivo</th>
                          <th style={{ ...ESTILOS.encabezadoTabla, width:36 }}></th>
                        </tr></thead>
                        <tbody>
                          {carritoEscaneo.map((item) => {
                            const loteActual = lotes.find((l) => l.id === item.loteId);
                            const stockMaximo = loteActual?.cantidad ?? item.cantidad;
                            return (
                              <tr key={item.idItem}>
                                <td style={ESTILOS.celdaTabla}>
                                  <div style={{ fontWeight:500, fontSize:13 }}>{item.nombreProducto}</div>
                                  <div style={{ fontSize:11, color:"#888780" }}>{item.marcaProducto}</div>
                                </td>
                                <td style={ESTILOS.celdaTabla}>
                                  <input
                                    type="number" min={1} max={stockMaximo}
                                    value={item.cantidad}
                                    onChange={(e) => {
                                      const nuevaCantidad = Math.min(parseInt(e.target.value) || 1, stockMaximo);
                                      setCarritoEscaneo((carritoActual) =>
                                        carritoActual.map((i) => i.idItem === item.idItem ? { ...i, cantidad: nuevaCantidad } : i)
                                      );
                                    }}
                                    style={{ width:"100%", padding:"4px 6px", border:"0.5px solid #d1d0c8", borderRadius:6, fontSize:13, fontWeight:500, color:"#791F1F" }}
                                  />
                                </td>
                                <td style={{ ...ESTILOS.celdaTabla, fontSize:11, fontFamily:"monospace", color:"#888780" }}>{formatearFecha(item.fechaCaducidadLote)}</td>
                                <td style={ESTILOS.celdaTabla}>
                                  <select
                                    value={item.motivo}
                                    onChange={(e) => setCarritoEscaneo((carritoActual) =>
                                      carritoActual.map((i) => i.idItem === item.idItem ? { ...i, motivo: e.target.value } : i)
                                    )}
                                    style={{ width:"100%", padding:"4px 6px", border:"0.5px solid #d1d0c8", borderRadius:6, fontSize:12 }}>
                                    {MOTIVOS_SALIDA.map((m) => <option key={m}>{m}</option>)}
                                  </select>
                                </td>
                                <td style={ESTILOS.celdaTabla}>
                                  <button
                                    onClick={() => setCarritoEscaneo((c) => c.filter((i) => i.idItem !== item.idItem))}
                                    style={{ border:"none", background:"transparent", cursor:"pointer", fontSize:16, color:"#888780", padding:"0 4px" }}>
                                    ×
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                    <div style={{ display:"flex", gap:8 }}>
                      <button onClick={registrarCarritoCompleto}
                        style={{ flex:1, padding:"10px 0", borderRadius:8, border:"0.5px solid #F09595", background:"#FCEBEB", fontSize:13, fontWeight:500, color:"#791F1F", cursor:"pointer" }}>
                        Registrar {carritoEscaneo.length} salida{carritoEscaneo.length > 1 ? "s" : ""}
                      </button>
                      <button onClick={() => setCarritoEscaneo([])}
                        style={{ padding:"10px 14px", borderRadius:8, border:"0.5px solid #e5e4dc", background:"transparent", fontSize:13, color:"#5f5e5a", cursor:"pointer" }}>
                        Limpiar
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* HISTORIAL */}
          {vistaActiva === "historial" && (
            <div>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:4, flexWrap:"wrap", gap:8 }}>
                <h2 style={{ fontSize:17, fontWeight:500 }}>Historial de movimientos</h2>
              </div>
              <p style={{ fontSize:12, color:"#5f5e5a", marginBottom:14 }}>
                {movimientosFiltrados.length} movimientos registrados
                {idMovimientoEditando && (
                  <span style={{ marginLeft:10, color:"#633806", fontWeight:500 }}>
                    — Editando movimiento #{idMovimientoEditando}
                  </span>
                )}
              </p>

              {/* Aviso explicativo sobre edición */}
              <div style={{ background:"#FAEEDA", border:"0.5px solid #EF9F27", borderRadius:8, padding:"10px 14px", fontSize:12, color:"#633806", marginBottom:14 }}>
                <strong>¿Cómo corregir un error?</strong> Haz clic en el botón <strong>✏ Editar</strong> junto al movimiento que quieras corregir.
                Solo puedes cambiar la <strong>cantidad</strong> y el <strong>motivo</strong> — el tipo (entrada/salida) y el producto no se pueden modificar.
                El stock del lote se recalcula automáticamente.
              </div>

              <div style={{ display:"flex", gap:10, marginBottom:14, flexWrap:"wrap" }}>
                <input placeholder="Buscar por nombre o marca..." value={textoBusquedaHistorial} onChange={(e) => setTextoBusquedaHistorial(e.target.value)} style={{ ...ESTILOS.inputBase, flex:1, minWidth:180 }} />
                <select value={filtroTipoMovimiento} onChange={(e) => setFiltroTipoMovimiento(e.target.value)} style={{ ...ESTILOS.inputBase, minWidth:160 }}>
                  <option value="">Todos los movimientos</option>
                  <option value="entrada">Solo entradas</option>
                  <option value="salida">Solo salidas</option>
                </select>
              </div>

              <div style={ESTILOS.tarjeta}>
                <table style={{ width:"100%", borderCollapse:"collapse", tableLayout:"fixed" }}>
                  <thead>
                    <tr>
                      <th style={{ ...ESTILOS.encabezadoTabla, width:125 }}>Fecha y hora</th>
                      <th style={ESTILOS.encabezadoTabla}>Producto</th>
                      <th style={{ ...ESTILOS.encabezadoTabla, width:90 }}>Tipo</th>
                      <th style={{ ...ESTILOS.encabezadoTabla, width:70 }}>Cant.</th>
                      <th style={{ ...ESTILOS.encabezadoTabla, width:55 }}>Lote</th>
                      <th style={ESTILOS.encabezadoTabla}>Motivo / Detalle</th>
                      <th style={{ ...ESTILOS.encabezadoTabla, width:36 }}></th>
                    </tr>
                  </thead>
                  <tbody>
                    {movimientosFiltrados.map((movimiento) => {
                      const producto       = productos.find((p) => p.id === movimiento.productoId);
                      const esEntrada      = movimiento.tipo === "entrada";
                      const estaEditando   = idMovimientoEditando === movimiento.id;
                      const motivosDelTipo = esEntrada ? MOTIVOS_ENTRADA : MOTIVOS_SALIDA;

                      return (
                        <React.Fragment key={movimiento.id}>
                          {/* Fila normal del movimiento */}
                          <tr style={{ background: estaEditando ? "#FFF9EC" : "transparent" }}>
                            <td style={{ ...ESTILOS.celdaTabla, fontSize:11, color:"#5f5e5a", fontFamily:"monospace" }}>{movimiento.fecha}</td>
                            <td style={ESTILOS.celdaTabla}>
                              <div style={{ fontWeight:500, fontSize:13 }}>{producto?.nombre}</div>
                              <div style={{ fontSize:11, color:"#888780" }}>{producto?.marca}</div>
                            </td>
                            <td style={ESTILOS.celdaTabla}>
                              <span style={{ fontSize:11, padding:"2px 9px", borderRadius:20, fontWeight:500,
                                background: esEntrada ? "#EAF3DE" : "#FCEBEB",
                                color:      esEntrada ? "#27500A"  : "#791F1F",
                                border:     `0.5px solid ${esEntrada ? "#97C459" : "#F09595"}` }}>
                                {esEntrada ? "Entrada" : "Salida"}
                              </span>
                            </td>
                            <td style={{ ...ESTILOS.celdaTabla, fontWeight:500, color: esEntrada ? "#27500A" : "#791F1F" }}>
                              {esEntrada ? "+" : "-"}{movimiento.cantidad}
                            </td>
                            <td style={{ ...ESTILOS.celdaTabla, fontSize:12, color:"#888780" }}>#{movimiento.loteId}</td>
                            <td style={{ ...ESTILOS.celdaTabla, fontSize:12, color:"#5f5e5a" }}>
                              {movimiento.motivo}
                              {movimiento.modo === "cajas" && movimiento.cajas && (
                                <span style={{ color:"#888780" }}> ({movimiento.cajas} cajas × {movimiento.unidadesCaja})</span>
                              )}
                            </td>
                            <td style={ESTILOS.celdaTabla}>
                              {estaEditando ? (
                                <button
                                  onClick={cancelarEdicionMovimiento}
                                  title="Cancelar edición"
                                  style={{ border:"none", background:"transparent", cursor:"pointer", fontSize:18, color:"#888780", padding:"0 4px", lineHeight:1 }}>
                                  ×
                                </button>
                              ) : (
                                <button
                                  onClick={() => abrirEdicionMovimiento(movimiento)}
                                  title="Editar este movimiento"
                                  style={{ border:"none", background:"transparent", cursor:"pointer", fontSize:13, color:"#5f5e5a", padding:"0 4px" }}>
                                  ✏
                                </button>
                              )}
                            </td>
                          </tr>

                          {/* Fila de edición inline — aparece debajo del movimiento seleccionado */}
                          {estaEditando && (
                            <tr style={{ background:"#FFF9EC" }}>
                              <td colSpan={7} style={{ padding:"12px 14px", borderBottom:"0.5px solid #e5e4dc" }}>
                                <div style={{ display:"flex", gap:12, alignItems:"flex-end", flexWrap:"wrap" }}>

                                  {/* Campo cantidad */}
                                  <div style={{ flex:"0 0 120px" }}>
                                    <label style={{ display:"block", fontSize:11, color:"#633806", marginBottom:4, fontWeight:500 }}>
                                      Cantidad corregida
                                    </label>
                                    <input
                                      type="number"
                                      min={1}
                                      value={formEdicionMovimiento.cantidad}
                                      onChange={(e) => setFormEdicionMovimiento((f) => ({ ...f, cantidad: e.target.value }))}
                                      style={{ ...ESTILOS.inputBase, borderColor:"#EF9F27" }}
                                      autoFocus
                                    />
                                  </div>

                                  {/* Campo motivo */}
                                  <div style={{ flex:"1 1 180px" }}>
                                    <label style={{ display:"block", fontSize:11, color:"#633806", marginBottom:4, fontWeight:500 }}>
                                      Motivo corregido
                                    </label>
                                    <select
                                      value={formEdicionMovimiento.motivo}
                                      onChange={(e) => setFormEdicionMovimiento((f) => ({ ...f, motivo: e.target.value }))}
                                      style={{ ...ESTILOS.inputBase, borderColor:"#EF9F27" }}>
                                      {motivosDelTipo.map((m) => <option key={m}>{m}</option>)}
                                    </select>
                                  </div>

                                  {/* Botones acción */}
                                  <div style={{ display:"flex", gap:8, flex:"0 0 auto" }}>
                                    <button
                                      onClick={guardarEdicionMovimiento}
                                      style={{ padding:"8px 16px", borderRadius:8, border:"0.5px solid #EF9F27", background:"#FAEEDA", fontSize:13, fontWeight:500, color:"#633806", cursor:"pointer" }}>
                                      Guardar corrección
                                    </button>
                                    <button
                                      onClick={cancelarEdicionMovimiento}
                                      style={{ padding:"8px 12px", borderRadius:8, border:"0.5px solid #e5e4dc", background:"transparent", fontSize:13, color:"#5f5e5a", cursor:"pointer" }}>
                                      Cancelar
                                    </button>
                                  </div>

                                  {/* Nota informativa */}
                                  <div style={{ flex:"1 1 100%", fontSize:11, color:"#888780", marginTop:4 }}>
                                    Cantidad original: <strong style={{ color:"#5f5e5a" }}>{formEdicionMovimiento.cantidadOriginal}</strong> uds
                                    {" · "}Lote #{formEdicionMovimiento.loteId}
                                    {" · "}Solo se puede editar cantidad y motivo. El tipo ({movimiento.tipo}) y el producto no cambian.
                                  </div>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* UNIDADES DE MEDIDA */}
          {vistaActiva === "unidades" && (
            <div style={{ maxWidth:480 }}>
              <h2 style={{ fontSize:17, fontWeight:500, marginBottom:4 }}>Unidades de medida</h2>
              <p style={{ fontSize:12, color:"#5f5e5a", marginBottom:18 }}>
                Personaliza las unidades disponibles al registrar un producto.
                No puedes eliminar una unidad si hay productos que la usan.
              </p>

              {/* Agregar nueva unidad */}
              <div style={{ ...ESTILOS.formulario, marginBottom:16 }}>
                <div style={{ fontSize:13, fontWeight:500, marginBottom:10 }}>Agregar nueva unidad</div>
                <div style={{ display:"flex", gap:8 }}>
                  <input
                    value={nuevaUnidad}
                    onChange={(e) => setNuevaUnidad(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") agregarUnidadMedida(); }}
                    placeholder="Ej: Docena, Quintal, Rollo..."
                    style={{ ...ESTILOS.inputBase, flex:1 }}
                  />
                  <button onClick={agregarUnidadMedida}
                    style={{ padding:"8px 16px", borderRadius:8, border:"0.5px solid #97C459", background:"#EAF3DE", fontSize:13, fontWeight:500, color:"#27500A", cursor:"pointer", whiteSpace:"nowrap" }}>
                    + Agregar
                  </button>
                </div>
              </div>

              {/* Lista de unidades existentes */}
              <div style={ESTILOS.tarjeta}>
                <table style={{ width:"100%", borderCollapse:"collapse" }}>
                  <thead><tr>
                    <th style={ESTILOS.encabezadoTabla}>Unidad</th>
                    <th style={{ ...ESTILOS.encabezadoTabla, width:120 }}>Productos</th>
                    <th style={{ ...ESTILOS.encabezadoTabla, width:80 }}>Acciones</th>
                  </tr></thead>
                  <tbody>
                    {unidadesMedida.map((unidad, indice) => {
                      const cantProductosConEstaUnidad = productos.filter((p) => p.unidad === unidad).length;
                      const estaEditandoEstaUnidad     = idUnidadEditando === indice;
                      return (
                        <tr key={unidad + indice}>
                          <td style={ESTILOS.celdaTabla}>
                            {estaEditandoEstaUnidad ? (
                              <input
                                value={textoUnidadEditando}
                                onChange={(e) => setTextoUnidadEditando(e.target.value)}
                                onKeyDown={(e) => { if (e.key === "Enter") guardarEdicionUnidad(indice); if (e.key === "Escape") { setIdUnidadEditando(null); setTextoUnidadEditando(""); } }}
                                style={{ ...ESTILOS.inputBase, padding:"5px 8px" }}
                                autoFocus
                              />
                            ) : (
                              <span style={{ fontSize:13, fontWeight:500 }}>{unidad}</span>
                            )}
                          </td>
                          <td style={{ ...ESTILOS.celdaTabla, fontSize:12, color:"#5f5e5a" }}>
                            {cantProductosConEstaUnidad > 0
                              ? `${cantProductosConEstaUnidad} producto${cantProductosConEstaUnidad > 1 ? "s" : ""}`
                              : <span style={{ color:"#888780" }}>Sin usar</span>}
                          </td>
                          <td style={{ ...ESTILOS.celdaTabla, padding:"6px 8px" }}>
                            {estaEditandoEstaUnidad ? (
                              <div style={{ display:"flex", gap:4 }}>
                                <button onClick={() => guardarEdicionUnidad(indice)}
                                  style={{ border:"none", background:"transparent", cursor:"pointer", fontSize:12, color:"#27500A", padding:"3px 6px", borderRadius:4, fontWeight:500 }}>
                                  ✓
                                </button>
                                <button onClick={() => { setIdUnidadEditando(null); setTextoUnidadEditando(""); }}
                                  style={{ border:"none", background:"transparent", cursor:"pointer", fontSize:14, color:"#888780", padding:"3px 5px", borderRadius:4 }}>
                                  ×
                                </button>
                              </div>
                            ) : (
                              <div style={{ display:"flex", gap:4 }}>
                                <button
                                  onClick={() => { setIdUnidadEditando(indice); setTextoUnidadEditando(unidad); }}
                                  title="Editar nombre"
                                  style={{ border:"none", background:"transparent", cursor:"pointer", fontSize:13, color:"#5f5e5a", padding:"3px 5px", borderRadius:4 }}>
                                  ✏
                                </button>
                                <button
                                  onClick={() => eliminarUnidadMedida(indice)}
                                  title={cantProductosConEstaUnidad > 0 ? "No se puede eliminar — tiene productos asignados" : "Eliminar unidad"}
                                  style={{ border:"none", background:"transparent", cursor: cantProductosConEstaUnidad > 0 ? "not-allowed" : "pointer", fontSize:13, color: cantProductosConEstaUnidad > 0 ? "#d1d0c8" : "#888780", padding:"3px 5px", borderRadius:4 }}>
                                  🗑
                                </button>
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* DIVISA / MONEDA */}
          {vistaActiva === "divisa" && (
            <div style={{ maxWidth:480 }}>
              <h2 style={{ fontSize:17, fontWeight:500, marginBottom:4 }}>Divisa / Moneda</h2>
              <p style={{ fontSize:12, color:"#5f5e5a", marginBottom:18 }}>
                Cambia el símbolo de moneda que aparece en todas las tablas y formularios de precio.
                Solo cambia la visualización — los valores numéricos no se convierten.
              </p>

              <div style={ESTILOS.tarjeta}>
                {DIVISAS_DISPONIBLES.map((divisa) => {
                  const estaSeleccionada = divisaActual.codigo === divisa.codigo;
                  return (
                    <div
                      key={divisa.codigo}
                      onClick={() => setDivisaActual(divisa)}
                      style={{
                        display:"flex", alignItems:"center", gap:14,
                        padding:"14px 16px", cursor:"pointer",
                        borderBottom:"0.5px solid #e5e4dc",
                        background: estaSeleccionada ? "#EAF3DE" : "transparent",
                        transition:"background .1s",
                      }}
                    >
                      {/* Símbolo */}
                      <div style={{
                        width:44, height:44, borderRadius:10,
                        background: estaSeleccionada ? "#27500A" : "#e8e7e0",
                        display:"flex", alignItems:"center", justifyContent:"center",
                        fontSize:18, fontWeight:700, flexShrink:0,
                        color: estaSeleccionada ? "#fff" : "#5f5e5a",
                      }}>
                        {divisa.simbolo}
                      </div>

                      {/* Nombre y ejemplo */}
                      <div style={{ flex:1 }}>
                        <div style={{ fontSize:13, fontWeight:500, color: estaSeleccionada ? "#27500A" : "#1a1a1a" }}>
                          {divisa.nombre}
                          <span style={{ fontSize:11, fontWeight:400, color:"#888780", marginLeft:8 }}>{divisa.codigo}</span>
                        </div>
                        <div style={{ fontSize:12, color:"#888780", marginTop:2, fontFamily:"monospace" }}>
                          Ejemplo: {divisa.ejemplo}
                        </div>
                      </div>

                      {/* Indicador seleccionado */}
                      {estaSeleccionada && (
                        <div style={{ fontSize:18, color:"#27500A", flexShrink:0 }}>✓</div>
                      )}
                    </div>
                  );
                })}
              </div>

              <div style={{ marginTop:14, background:"#FAEEDA", border:"0.5px solid #EF9F27", borderRadius:8, padding:"10px 14px", fontSize:12, color:"#633806" }}>
                <strong>Nota:</strong> Este cambio solo afecta el símbolo visible ({divisaActual.simbolo}).
                Los precios registrados no se convierten a otra moneda — solo cambia cómo se muestran.
              </div>
            </div>
          )}

        </main>
      </div>
    </div>
  );
}
